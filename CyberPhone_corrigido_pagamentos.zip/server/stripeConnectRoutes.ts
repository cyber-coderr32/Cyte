import express, { Request, Response, Router } from "express";
import { getStripeClient } from "./stripeClient";
import { getAdminDb } from "./firebaseAdmin";

const router: Router = express.Router();

function getAppUrl(req: Request): string {
  return process.env.APP_PUBLIC_URL || `${req.protocol}://${req.get("host")}`;
}

function maskIban(iban?: string | null): string | undefined {
  if (!iban) return undefined;
  const clean = iban.replace(/\s+/g, "");
  if (clean.length <= 6) return clean;
  return `${clean.slice(0, 4)}${"*".repeat(Math.max(0, clean.length - 8))}${clean.slice(-4)}`;
}

/**
 * POST /api/stripe/connect/onboard
 *
 * Cria (se ainda não existir) uma conta Stripe Connect Custom para o usuário,
 * e retorna a URL de Onboarding hospedado pela Stripe (Connect Onboarding),
 * que recolhe KYC, dados bancários (IBAN) e aceitação dos termos.
 *
 * Body: { userId: string, email: string, country?: string }
 */
router.post("/onboard", async (req: Request, res: Response) => {
  const stripe = getStripeClient();
  const adminDb = getAdminDb();
  if (!stripe || !adminDb) {
    return res.status(503).json({ error: "Serviço de pagamentos indisponível: Stripe ou Firebase Admin não configurados." });
  }

  try {
    const { userId, email, country } = req.body || {};
    if (!userId || typeof userId !== "string") {
      return res.status(400).json({ error: "userId é obrigatório." });
    }

    const connectRef = adminDb.collection("stripe_connect_accounts").doc(userId);
    const existingSnap = await connectRef.get();
    let stripeAccountId: string;

    if (existingSnap.exists && (existingSnap.data() as any)?.stripeAccountId) {
      stripeAccountId = (existingSnap.data() as any).stripeAccountId;
    } else {
      // Cria a conta Custom. country é o país de operação do vendedor;
      // como a Stripe não opera nativamente em Angola, o vendedor deve
      // selecionar um país suportado (ex: Portugal) durante o onboarding
      // caso 'country' não seja informado ou não seja suportado.
      const account = await stripe.accounts.create({
        type: "custom",
        country: country || "PT",
        email: email || undefined,
        capabilities: {
          transfers: { requested: true },
          card_payments: { requested: true },
        },
        business_type: "individual",
        metadata: { appUserId: userId },
        tos_acceptance: { service_agreement: "recipient" },
      });
      stripeAccountId = account.id;

      await connectRef.set({
        userId,
        stripeAccountId,
        status: "INFO_REQUIRED",
        payoutsEnabled: false,
        chargesEnabled: false,
        detailsSubmitted: false,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });

      await adminDb.collection("profiles").doc(userId).update({
        stripeConnectAccountId: stripeAccountId,
        stripeConnectStatus: "INFO_REQUIRED",
      }).catch(() => { /* perfil pode ainda não existir nesse formato; não bloquear onboarding por isso */ });
    }

    const appUrl = getAppUrl(req);
    const accountLink = await stripe.accountLinks.create({
      account: stripeAccountId,
      refresh_url: `${appUrl}/?stripe_connect_refresh=1`,
      return_url: `${appUrl}/?stripe_connect_return=1`,
      type: "account_onboarding",
      collection_options: { fields: "eventually_due" },
    });

    res.json({ url: accountLink.url, stripeAccountId });
  } catch (error: any) {
    console.error("[StripeConnect] Erro no onboarding:", error.message);
    res.status(500).json({ error: error.message || "Falha ao iniciar onboarding com a Stripe Connect." });
  }
});

/**
 * GET /api/stripe/connect/status/:userId
 *
 * Consulta o estado atual da conta Connect diretamente na Stripe (fonte de
 * verdade) e sincroniza o Firestore. Deve ser chamado quando o usuário
 * retorna do fluxo de onboarding (return_url) e periodicamente na página
 * de configurações.
 */
router.get("/status/:userId", async (req: Request, res: Response) => {
  const stripe = getStripeClient();
  const adminDb = getAdminDb();
  if (!stripe || !adminDb) {
    return res.status(503).json({ error: "Serviço indisponível." });
  }

  try {
    const { userId } = req.params;
    const connectSnap = await adminDb.collection("stripe_connect_accounts").doc(userId).get();
    if (!connectSnap.exists) {
      return res.json({ status: "NOT_STARTED" });
    }
    const connectData = connectSnap.data() as any;
    const account = await stripe.accounts.retrieve(connectData.stripeAccountId);

    let status: string = "INFO_REQUIRED";
    if (account.requirements?.disabled_reason?.startsWith("rejected")) {
      status = "REJECTED";
    } else if ((account.requirements?.currently_due?.length || 0) > 0 || (account.requirements?.past_due?.length || 0) > 0) {
      status = account.details_submitted ? "PENDING_REVIEW" : "INFO_REQUIRED";
    } else if (account.charges_enabled && account.payouts_enabled) {
      status = "ACTIVE";
    } else if (account.details_submitted) {
      status = "PENDING_REVIEW";
    }

    const externalAccount = (account.external_accounts?.data || []).find((a: any) => a.object === "bank_account") as any;

    const updatedData = {
      status,
      payoutsEnabled: !!account.payouts_enabled,
      chargesEnabled: !!account.charges_enabled,
      detailsSubmitted: !!account.details_submitted,
      requirementsCurrentlyDue: account.requirements?.currently_due || [],
      requirementsPastDue: account.requirements?.past_due || [],
      bankAccountLast4: externalAccount?.last4 || null,
      bankAccountCountry: externalAccount?.country || null,
      defaultCurrency: account.default_currency || null,
      updatedAt: Date.now(),
    };

    await adminDb.collection("stripe_connect_accounts").doc(userId).update(updatedData);
    await adminDb.collection("profiles").doc(userId).update({ stripeConnectStatus: status }).catch(() => {});

    res.json({ ...updatedData, stripeAccountId: connectData.stripeAccountId });
  } catch (error: any) {
    console.error("[StripeConnect] Erro ao consultar status:", error.message);
    res.status(500).json({ error: error.message || "Falha ao consultar status da conta Connect." });
  }
});

/**
 * POST /api/stripe/connect/bank-account
 *
 * Associa/atualiza o IBAN do vendedor na conta Connect Custom diretamente
 * pela API (alternativa a fazer isso dentro do Onboarding hospedado, útil
 * caso o usuário queira trocar de banco depois de já ter uma conta ativa).
 *
 * Body: { userId: string, iban: string, accountHolderName: string, country: string, currency?: string }
 */
router.post("/bank-account", async (req: Request, res: Response) => {
  const stripe = getStripeClient();
  const adminDb = getAdminDb();
  if (!stripe || !adminDb) {
    return res.status(503).json({ error: "Serviço indisponível." });
  }

  try {
    const { userId, iban, accountHolderName, country, currency } = req.body || {};
    if (!userId || !iban || !accountHolderName || !country) {
      return res.status(400).json({ error: "userId, iban, accountHolderName e country são obrigatórios." });
    }

    const connectSnap = await adminDb.collection("stripe_connect_accounts").doc(userId).get();
    if (!connectSnap.exists) {
      return res.status(404).json({ error: "Nenhuma conta Stripe Connect encontrada. Inicie o onboarding primeiro." });
    }
    const stripeAccountId = (connectSnap.data() as any).stripeAccountId;

    const externalAccount = await stripe.accounts.createExternalAccount(stripeAccountId, {
      external_account: {
        object: "bank_account",
        country: String(country).toUpperCase(),
        currency: (currency || "eur").toLowerCase(),
        account_holder_name: accountHolderName,
        account_holder_type: "individual",
        account_number: iban,
      } as any,
    });

    await adminDb.collection("stripe_connect_accounts").doc(userId).update({
      iban: maskIban(iban),
      bankAccountLast4: (externalAccount as any).last4 || null,
      bankAccountCountry: (externalAccount as any).country || null,
      updatedAt: Date.now(),
    });

    res.json({ success: true, last4: (externalAccount as any).last4 });
  } catch (error: any) {
    console.error("[StripeConnect] Erro ao associar conta bancária:", error.message);
    res.status(400).json({ error: error.message || "Falha ao associar a conta bancária (verifique se o IBAN é válido para o país selecionado)." });
  }
});

/**
 * POST /api/stripe/issuing/cardholder-and-card
 *
 * Cria (se necessário) um Cardholder e emite um cartão virtual (Issuing)
 * na própria conta Connect do vendedor, para que ele possa gastar o saldo
 * de vendas. Exige que a conta Connect já esteja ACTIVE.
 *
 * Body: { userId: string, name: string, email: string, billingAddress: {...} }
 */
router.post("/issuing/card", async (req: Request, res: Response) => {
  const stripe = getStripeClient();
  const adminDb = getAdminDb();
  if (!stripe || !adminDb) {
    return res.status(503).json({ error: "Serviço indisponível." });
  }

  try {
    const { userId, name, email, billingAddress } = req.body || {};
    if (!userId || !name || !billingAddress) {
      return res.status(400).json({ error: "userId, name e billingAddress são obrigatórios." });
    }

    const connectSnap = await adminDb.collection("stripe_connect_accounts").doc(userId).get();
    if (!connectSnap.exists) {
      return res.status(404).json({ error: "Nenhuma conta Stripe Connect encontrada. Complete o onboarding primeiro." });
    }
    const connectData = connectSnap.data() as any;
    const stripeAccountId = connectData.stripeAccountId;

    if (connectData.status !== "ACTIVE") {
      return res.status(403).json({ error: "A conta Connect ainda não está ativa. Complete a verificação antes de solicitar um cartão." });
    }

    // Ativa a capability de card_issuing na conta conectada, caso ainda não esteja.
    await stripe.accounts.update(stripeAccountId, {
      capabilities: { card_issuing: { requested: true } },
    }).catch((err) => {
      console.warn("[Issuing] Aviso ao solicitar capability card_issuing (pode já estar ativa):", err.message);
    });

    const existingCardholderId = connectData.stripeCardholderId;
    let cardholderId = existingCardholderId;

    if (!cardholderId) {
      const cardholder = await stripe.issuing.cardholders.create(
        {
          name,
          email: email || undefined,
          status: "active",
          type: "individual",
          billing: { address: billingAddress },
        },
        { stripeAccount: stripeAccountId }
      );
      cardholderId = cardholder.id;
      await adminDb.collection("stripe_connect_accounts").doc(userId).update({ stripeCardholderId: cardholderId });
    }

    const card = await stripe.issuing.cards.create(
      {
        cardholder: cardholderId,
        currency: "eur",
        type: "virtual",
        status: "active",
      },
      { stripeAccount: stripeAccountId }
    );

    const virtualCardDoc = {
      id: card.id,
      userId,
      stripeCardId: card.id,
      stripeCardholderId: cardholderId,
      status: "ACTIVE",
      last4: card.last4,
      expMonth: card.exp_month,
      expYear: card.exp_year,
      brand: (card as any).brand || "visa",
      createdAt: Date.now(),
    };

    await adminDb.collection("virtual_cards").doc(card.id).set(virtualCardDoc);

    res.json(virtualCardDoc);
  } catch (error: any) {
    console.error("[Issuing] Erro ao criar cartão virtual:", error.message);
    res.status(500).json({ error: error.message || "Falha ao emitir cartão virtual." });
  }
});

/**
 * GET /api/stripe/issuing/cards/:userId
 * Lista os cartões virtuais já emitidos para o usuário (sem dados sensíveis —
 * número completo e CVC nunca passam pelo nosso servidor sem necessidade explícita).
 */
router.get("/issuing/cards/:userId", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { userId } = req.params;
    const snap = await adminDb.collection("virtual_cards").where("userId", "==", userId).get();
    res.json(snap.docs.map((d) => d.data()));
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Falha ao listar cartões virtuais." });
  }
});

export default router;
