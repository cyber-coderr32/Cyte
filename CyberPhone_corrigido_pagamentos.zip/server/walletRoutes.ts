import express, { Request, Response, Router } from "express";
import { getAdminDb, FieldValue } from "./firebaseAdmin";
import type { Firestore, Query } from "firebase-admin/firestore";
import crypto from "crypto";

const router: Router = express.Router();

function generateId(): string {
  return crypto.randomUUID();
}

/**
 * Confirma, no servidor, que quem está a chamar esta rota é mesmo um admin.
 * Usamos o próprio Firestore (via Admin SDK) como fonte de verdade, lendo o
 * perfil do solicitante — nunca confiamos numa flag enviada pelo cliente.
 */
async function requireAdmin(adminDb: Firestore, requesterId: string | undefined): Promise<boolean> {
  if (!requesterId) return false;
  const snap = await adminDb.collection("profiles").doc(requesterId).get();
  if (!snap.exists) return false;
  return !!(snap.data() as any)?.isAdmin;
}

/**
 * GET /api/wallet/requests?status=PENDING&requesterId=...
 * Lista pedidos de depósito/levantamento manual. Apenas administradores.
 */
router.get("/requests", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { status, requesterId } = req.query as { status?: string; requesterId?: string };
    if (!(await requireAdmin(adminDb, requesterId))) {
      return res.status(403).json({ error: "Apenas administradores podem listar pedidos da carteira." });
    }

    let queryRef: Query = adminDb.collection("wallet_requests");
    if (status) queryRef = queryRef.where("status", "==", status);
    const snap = await queryRef.orderBy("createdAt", "desc").limit(200).get();
    res.json(snap.docs.map((d) => d.data()));
  } catch (error: any) {
    console.error("[WalletRequests] Erro ao listar:", error.message);
    res.status(500).json({ error: error.message || "Falha ao listar pedidos." });
  }
});

/**
 * POST /api/wallet/requests/:requestId/approve
 * Aprova um pedido PENDING: credita/debita o saldo do usuário (via Admin SDK,
 * nunca pelo cliente) e regista a transação. Apenas administradores.
 *
 * Body: { requesterId: string, adminNote?: string }
 */
router.post("/requests/:requestId/approve", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { requestId } = req.params;
    const { requesterId, adminNote } = req.body || {};

    if (!(await requireAdmin(adminDb, requesterId))) {
      return res.status(403).json({ error: "Apenas administradores podem aprovar pedidos da carteira." });
    }

    const requestRef = adminDb.collection("wallet_requests").doc(requestId);

    await adminDb.runTransaction(async (tx) => {
      const snap = await tx.get(requestRef);
      if (!snap.exists) throw new Error("Pedido não encontrado.");
      const data = snap.data() as any;

      if (data.status !== "PENDING") {
        throw new Error("Este pedido já foi processado anteriormente.");
      }

      const { userId, amountKz, type } = data;
      const profileRef = adminDb.collection("profiles").doc(userId);
      const publicProfileRef = adminDb.collection("public_profiles").doc(userId);

      if (type === "DEPOSIT") {
        tx.update(profileRef, { balance: FieldValue.increment(amountKz) });
        tx.update(publicProfileRef, { balance: FieldValue.increment(amountKz) });
      } else if (type === "WITHDRAWAL") {
        // Revalida saldo suficiente no momento da aprovação (pode ter mudado desde o pedido).
        const profileSnap = await tx.get(profileRef);
        const currentBalance = (profileSnap.data() as any)?.balance || 0;
        if (currentBalance < amountKz) {
          throw new Error("O usuário já não possui saldo suficiente para este levantamento.");
        }
        tx.update(profileRef, {
          balance: FieldValue.increment(-amountKz),
          totalWithdrawn: FieldValue.increment(amountKz),
        });
        tx.update(publicProfileRef, { balance: FieldValue.increment(-amountKz) });
      }

      const txId = generateId();
      tx.set(adminDb.collection("transactions").doc(txId), {
        id: txId,
        userId,
        type,
        amount: type === "DEPOSIT" ? amountKz : -amountKz,
        description: type === "DEPOSIT" ? "Depósito manual aprovado (Multicaixa/Unitel)" : "Levantamento manual aprovado",
        timestamp: Date.now(),
        status: "COMPLETED",
      });

      tx.update(requestRef, {
        status: "APPROVED",
        resolvedAt: Date.now(),
        resolvedBy: requesterId,
        adminNote: adminNote || "",
      });
    });

    res.json({ success: true });
  } catch (error: any) {
    console.error("[WalletRequests] Erro ao aprovar:", error.message);
    res.status(400).json({ error: error.message || "Falha ao aprovar o pedido." });
  }
});

/**
 * POST /api/wallet/requests/:requestId/reject
 * Rejeita um pedido PENDING sem alterar nenhum saldo. Apenas administradores.
 */
router.post("/requests/:requestId/reject", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { requestId } = req.params;
    const { requesterId, adminNote } = req.body || {};

    if (!(await requireAdmin(adminDb, requesterId))) {
      return res.status(403).json({ error: "Apenas administradores podem rejeitar pedidos da carteira." });
    }

    const requestRef = adminDb.collection("wallet_requests").doc(requestId);
    const snap = await requestRef.get();
    if (!snap.exists) return res.status(404).json({ error: "Pedido não encontrado." });
    if ((snap.data() as any)?.status !== "PENDING") {
      return res.status(400).json({ error: "Este pedido já foi processado anteriormente." });
    }

    await requestRef.update({
      status: "REJECTED",
      resolvedAt: Date.now(),
      resolvedBy: requesterId,
      adminNote: adminNote || "",
    });

    res.json({ success: true });
  } catch (error: any) {
    console.error("[WalletRequests] Erro ao rejeitar:", error.message);
    res.status(500).json({ error: error.message || "Falha ao rejeitar o pedido." });
  }
});

/**
 * POST /api/wallet/checkout
 *
 * Processa uma compra do carrinho paga com o SALDO da carteira do usuário
 * (sem cartão). Substitui o antigo processProductPurchase do cliente, que
 * escrevia diretamente no Firestore — agora tudo passa pelo Admin SDK no
 * servidor, fechando a possibilidade de um usuário manipular o próprio
 * saldo diretamente via DevTools.
 *
 * Body: { userId, items, affiliateId?, shippingAddress, carrier? }
 */
router.post("/checkout", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { userId, items, affiliateId, shippingAddress, carrier } = req.body || {};

    if (!userId || typeof userId !== "string") {
      return res.status(400).json({ error: "userId é obrigatório." });
    }
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "items é obrigatório e não pode estar vazio." });
    }

    const buyerSnap = await adminDb.collection("profiles").doc(userId).get();
    if (!buyerSnap.exists) return res.status(404).json({ error: "Usuário não encontrado." });
    const buyer = buyerSnap.data() as any;
    if (buyer.isFrozen) {
      return res.status(403).json({ error: "Esta conta está temporariamente bloqueada para transações financeiras." });
    }

    const settingsSnap = await adminDb.collection("settings").doc("global").get();
    const rawTax = settingsSnap.exists ? (settingsSnap.data() as any)?.platformTax ?? 0.1 : 0.1;
    const platformTax = rawTax > 1 ? rawTax / 100 : rawTax; // tolera 0.1 (já fração) ou 10 (percentagem)

    const batchTimestamp = Date.now();
    const createdSaleIds: string[] = [];
    let totalCharged = 0;

    // Primeiro calculamos o total e validamos saldo ANTES de qualquer escrita,
    // para não debitar parcialmente em caso de saldo insuficiente.
    const resolvedItems: any[] = [];
    for (const item of items) {
      const productSnap = await adminDb.collection("products").doc(item.productId).get();
      if (!productSnap.exists) continue;
      const product = productSnap.data() as any;

      const storeSnap = await adminDb.collection("stores").doc(product.storeId).get();
      if (!storeSnap.exists) continue;
      const store = storeSnap.data() as any;
      const sellerId = store.userId;

      let unitPrice = product.price;
      if (item.selectedColor) {
        const matchedVariant = (product.variants || []).find((v: any) => v.name === item.selectedColor || v.id === item.selectedColor);
        if (matchedVariant) unitPrice = matchedVariant.price;
      }

      const shippingCost = (product.type === "PHYSICAL" && !product.hasFreeShipping) ? (product.shippingFee || 0) : 0;
      const totalAmount = (unitPrice * item.quantity) + shippingCost;
      totalCharged += totalAmount;

      resolvedItems.push({ item, product, sellerId, totalAmount });
    }

    if ((buyer.balance || 0) < totalCharged) {
      return res.status(400).json({ error: "Saldo insuficiente para concluir esta compra." });
    }

    // Debita o comprador numa única operação atómica.
    await adminDb.runTransaction(async (tx) => {
      const freshBuyerSnap = await tx.get(adminDb.collection("profiles").doc(userId));
      const freshBalance = (freshBuyerSnap.data() as any)?.balance || 0;
      if (freshBalance < totalCharged) {
        throw new Error("Saldo insuficiente para concluir esta compra.");
      }
      tx.update(adminDb.collection("profiles").doc(userId), { balance: FieldValue.increment(-totalCharged) });
      tx.update(adminDb.collection("public_profiles").doc(userId), { balance: FieldValue.increment(-totalCharged) });
    });

    // Cria os registros de venda (escrow) e credita vendedores/afiliados.
    for (const { item, product, sellerId, totalAmount } of resolvedItems) {
      const saleId = generateId();
      const initialStatus = product.type === "PHYSICAL" ? "WAITLIST" : "DELIVERED";

      let sellerEarnings = totalAmount * (1 - platformTax);
      let affiliateEarnings = 0;
      const finalAffiliateId = item.affiliateId || affiliateId || null;

      if (finalAffiliateId && product.affiliateCommissionRate > 0) {
        affiliateEarnings = totalAmount * (product.affiliateCommissionRate / 100);
        sellerEarnings -= affiliateEarnings;
      }

      await adminDb.collection("sales").doc(saleId).set({
        id: saleId,
        productId: item.productId,
        buyerId: userId,
        sellerId,
        affiliateUserId: finalAffiliateId || "",
        storeId: product.storeId,
        timestamp: batchTimestamp,
        status: initialStatus,
        shippingAddress: shippingAddress || null,
        saleAmount: totalAmount,
        sellerEarnings,
        affiliateEarnings,
        fundsReleased: false,
        carrierId: carrier?.id || "",
        carrierName: carrier?.name || shippingAddress?.carrierName || "",
        selectedVariant: item.selectedColor || "",
        paymentMethod: "wallet",
      });
      createdSaleIds.push(saleId);

      await adminDb.collection("profiles").doc(sellerId).update({
        pendingBalance: FieldValue.increment(sellerEarnings),
        totalEarnings: FieldValue.increment(sellerEarnings),
      });

      if (finalAffiliateId && affiliateEarnings > 0) {
        await adminDb.collection("profiles").doc(finalAffiliateId).update({
          pendingBalance: FieldValue.increment(affiliateEarnings),
          totalEarnings: FieldValue.increment(affiliateEarnings),
        });
      }

      const buyTxId = generateId();
      await adminDb.collection("transactions").doc(buyTxId).set({
        id: buyTxId,
        userId,
        type: "PURCHASE",
        amount: -totalAmount,
        description: `Compra de produto: ${product.name || "Produto"} (Aguardando Recebimento)`,
        timestamp: batchTimestamp,
        status: "COMPLETED",
      });

      await adminDb.collection("products").doc(item.productId).update({
        soldCount: FieldValue.increment(item.quantity),
      });
    }

    res.json({ success: true, saleIds: createdSaleIds });
  } catch (error: any) {
    console.error("[WalletCheckout] Erro ao processar compra com saldo:", error.message);
    res.status(400).json({ error: error.message || "Falha ao processar a compra." });
  }
});

export default router;
