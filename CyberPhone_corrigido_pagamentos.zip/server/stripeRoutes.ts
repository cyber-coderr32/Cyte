import express, { Request, Response, Router } from "express";
import { getStripeClient, isStripeConfigured, STRIPE_CHECKOUT_CURRENCY, kzToStripeAmount, DEFAULT_EUR_TO_KZ_RATE } from "./stripeClient";
import { getAdminDb, FieldValue } from "./firebaseAdmin";
import type { Firestore } from "firebase-admin/firestore";
import crypto from "crypto";

const router: Router = express.Router();

function generateId(): string {
  return crypto.randomUUID();
}

async function getEurToKzRate(): Promise<number> {
  const adminDb = getAdminDb();
  if (!adminDb) return DEFAULT_EUR_TO_KZ_RATE;
  try {
    const snap = await adminDb.collection("settings").doc("global").get();
    const rate = snap.exists ? (snap.data() as any)?.eurToKzRate : undefined;
    return typeof rate === "number" && rate > 0 ? rate : DEFAULT_EUR_TO_KZ_RATE;
  } catch {
    return DEFAULT_EUR_TO_KZ_RATE;
  }
}

/**
 * POST /api/stripe/create-payment-intent
 *
 * Cria um PaymentIntent da Stripe para um depósito na carteira OU para o
 * checkout do carrinho. O saldo do usuário NUNCA é alterado aqui — apenas
 * quando o webhook confirmar que o pagamento foi de fato concluído.
 *
 * Body esperado:
 *   { userId: string, amountKz: number, purpose: 'WALLET_DEPOSIT' | 'CART_CHECKOUT', cartItems?: CartItem[] }
 */
router.post("/create-payment-intent", async (req: Request, res: Response) => {
  const stripe = getStripeClient();
  if (!stripe) {
    return res.status(503).json({ error: "Pagamentos por cartão (Stripe) ainda não foram configurados pelo administrador." });
  }

  const adminDb = getAdminDb();
  if (!adminDb) {
    return res.status(503).json({ error: "Serviço de pagamentos indisponível: credencial administrativa do Firebase não configurada." });
  }

  try {
    const { userId, amountKz, purpose, cartItems, shippingAddress, carrier, affiliateId } = req.body || {};

    if (!userId || typeof userId !== "string") {
      return res.status(400).json({ error: "userId é obrigatório." });
    }
    if (typeof amountKz !== "number" || !isFinite(amountKz) || amountKz <= 0) {
      return res.status(400).json({ error: "amountKz deve ser um número positivo." });
    }
    if (purpose !== "WALLET_DEPOSIT" && purpose !== "CART_CHECKOUT") {
      return res.status(400).json({ error: "purpose deve ser 'WALLET_DEPOSIT' ou 'CART_CHECKOUT'." });
    }
    if (purpose === "CART_CHECKOUT" && (!Array.isArray(cartItems) || cartItems.length === 0)) {
      return res.status(400).json({ error: "cartItems é obrigatório e não pode estar vazio para CART_CHECKOUT." });
    }

    // Confirma que o usuário existe antes de criar qualquer cobrança.
    const userSnap = await adminDb.collection("profiles").doc(userId).get();
    if (!userSnap.exists) {
      return res.status(404).json({ error: "Usuário não encontrado." });
    }
    const userData = userSnap.data() as any;
    if (userData?.isFrozen) {
      return res.status(403).json({ error: "Esta conta está temporariamente bloqueada para transações financeiras." });
    }

    const eurToKzRate = await getEurToKzRate();
    const stripeAmount = kzToStripeAmount(amountKz, eurToKzRate);

    const MIN_STRIPE_AMOUNT_CENTS = 50; // ~0.50 EUR, mínimo prático da Stripe para a maioria dos métodos
    if (stripeAmount < MIN_STRIPE_AMOUNT_CENTS) {
      return res.status(400).json({ error: "O valor mínimo para pagamento por cartão é de 0,50 EUR." });
    }

    const intentId = generateId();
    const now = Date.now();

    const paymentIntent = await stripe.paymentIntents.create({
      amount: stripeAmount,
      currency: STRIPE_CHECKOUT_CURRENCY,
      automatic_payment_methods: { enabled: true },
      metadata: {
        appPaymentIntentId: intentId,
        userId,
        purpose,
        amountKz: String(amountKz),
        eurToKzRate: String(eurToKzRate),
      },
    });

    // Regista a intenção no Firestore para auditoria e para o webhook conseguir localizá-la.
    await adminDb.collection("payment_intents").doc(intentId).set({
      id: intentId,
      userId,
      method: "stripe",
      purpose,
      amountKz,
      amountProviderCurrency: stripeAmount / 100,
      providerCurrency: STRIPE_CHECKOUT_CURRENCY,
      providerRef: paymentIntent.id,
      status: "PENDING",
      cartItems: purpose === "CART_CHECKOUT" ? (cartItems || []) : null,
      shippingAddress: purpose === "CART_CHECKOUT" ? (shippingAddress || null) : null,
      carrier: purpose === "CART_CHECKOUT" ? (carrier || null) : null,
      affiliateId: purpose === "CART_CHECKOUT" ? (affiliateId || null) : null,
      createdAt: now,
      updatedAt: now,
    });

    res.json({
      clientSecret: paymentIntent.client_secret,
      intentId,
      amountEur: stripeAmount / 100,
      eurToKzRate,
    });
  } catch (error: any) {
    console.error("[Stripe] Erro ao criar PaymentIntent:", error.message);
    res.status(500).json({ error: error.message || "Falha ao iniciar pagamento com a Stripe." });
  }
});

/**
 * GET /api/stripe/payment-intent/:intentId/status
 * Permite que o frontend confirme o estado de uma intenção (poll leve, complementar ao webhook).
 */
router.get("/payment-intent/:intentId/status", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { intentId } = req.params;
    const snap = await adminDb.collection("payment_intents").doc(intentId).get();
    if (!snap.exists) return res.status(404).json({ error: "Intenção de pagamento não encontrada." });
    const data = snap.data() as any;
    res.json({ status: data.status, purpose: data.purpose, amountKz: data.amountKz });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Falha ao consultar status do pagamento." });
  }
});

/**
 * POST /api/stripe/webhook
 *
 * Fonte única de verdade para confirmar pagamentos. O Express precisa do
 * corpo RAW (não parseado em JSON) para validar a assinatura — ver server.ts,
 * onde esta rota é montada com express.raw() antes do middleware json().
 */
export async function handleStripeWebhook(req: Request, res: Response) {
  const stripe = getStripeClient();
  const adminDb = getAdminDb();
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!stripe || !adminDb) {
    return res.status(503).send("Serviço de pagamentos indisponível.");
  }
  if (!webhookSecret) {
    console.error("[Stripe Webhook] STRIPE_WEBHOOK_SECRET não configurada — recusando processar evento por segurança.");
    return res.status(503).send("Webhook secret não configurado.");
  }

  const signature = req.headers["stripe-signature"] as string;
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, signature, webhookSecret);
  } catch (err: any) {
    console.error("[Stripe Webhook] Falha na verificação de assinatura:", err.message);
    return res.status(400).send(`Webhook signature verification failed: ${err.message}`);
  }

  try {
    switch (event.type) {
      case "payment_intent.succeeded": {
        const pi = event.data.object as any;
        await fulfillPaymentIntent(adminDb, pi);
        break;
      }
      case "payment_intent.payment_failed": {
        const pi = event.data.object as any;
        await markPaymentIntentFailed(adminDb, pi);
        break;
      }
      default:
        // Outros eventos (ex: relacionados à Connect) são tratados em stripeConnectRoutes.ts
        break;
    }
    res.json({ received: true });
  } catch (err: any) {
    console.error("[Stripe Webhook] Erro ao processar evento:", err.message);
    // Retornamos 500 para que a Stripe reenvie o evento (ela faz retry automático).
    res.status(500).send("Erro ao processar webhook.");
  }
}

async function fulfillPaymentIntent(adminDb: Firestore, pi: any) {
  const appIntentId = pi.metadata?.appPaymentIntentId;
  if (!appIntentId) {
    console.warn("[Stripe Webhook] PaymentIntent sem appPaymentIntentId nos metadados:", pi.id);
    return;
  }

  const intentRef = adminDb.collection("payment_intents").doc(appIntentId);

  // Transação para garantir que o mesmo evento (a Stripe pode reenviar) nunca credita saldo duas vezes.
  await adminDb.runTransaction(async (tx) => {
    const intentSnap = await tx.get(intentRef);
    if (!intentSnap.exists) {
      console.warn("[Stripe Webhook] Intenção de pagamento não encontrada no Firestore:", appIntentId);
      return;
    }
    const intentData = intentSnap.data() as any;

    // Idempotência: se já foi processada com sucesso, não fazemos nada.
    if (intentData.status === "SUCCEEDED") {
      return;
    }

    const { userId, purpose, amountKz } = intentData;
    const profileRef = adminDb.collection("profiles").doc(userId);
    const publicProfileRef = adminDb.collection("public_profiles").doc(userId);

    if (purpose === "WALLET_DEPOSIT") {
      tx.update(profileRef, { balance: FieldValue.increment(amountKz) });
      tx.update(publicProfileRef, { balance: FieldValue.increment(amountKz) });

      const txId = generateId();
      tx.set(adminDb.collection("transactions").doc(txId), {
        id: txId,
        userId,
        type: "DEPOSIT",
        amount: amountKz,
        description: "Depósito via cartão (Stripe)",
        timestamp: Date.now(),
        status: "COMPLETED",
      });
    }
    // CART_CHECKOUT: o crédito de saldo ao(s) vendedor(es) e a criação dos
    // registros de venda usam a mesma lógica de negócio do processProductPurchase
    // do storageService, replicada aqui no servidor para rodar com privilégios
    // de admin. Para manter este arquivo legível, isso é tratado por uma
    // função dedicada chamada fora da transação principal (ver checkoutFulfillment.ts).

    tx.update(intentRef, { status: "SUCCEEDED", updatedAt: Date.now() });
  });

  // Para compras no carrinho, finaliza a criação das vendas após confirmar o pagamento.
  const finalSnap = await intentRef.get();
  const finalData = finalSnap.data() as any;
  if (finalData?.purpose === "CART_CHECKOUT" && finalData?.status === "SUCCEEDED") {
    const { fulfillCartCheckout } = await import("./checkoutFulfillment");
    await fulfillCartCheckout(adminDb, finalData);
  }
}

async function markPaymentIntentFailed(adminDb: Firestore, pi: any) {
  const appIntentId = pi.metadata?.appPaymentIntentId;
  if (!appIntentId) return;
  const intentRef = adminDb.collection("payment_intents").doc(appIntentId);
  await intentRef.update({
    status: "FAILED",
    failureReason: pi.last_payment_error?.message || "Pagamento recusado.",
    updatedAt: Date.now(),
  }).catch((err) => console.error("[Stripe Webhook] Falha ao marcar intenção como FAILED:", err.message));
}

export default router;
