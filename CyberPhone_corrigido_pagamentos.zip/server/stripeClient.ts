import Stripe from "stripe";

// Versão de API fixa — evita que mudanças futuras na API da Stripe alterem
// o formato das respostas sem que o código seja atualizado deliberadamente.
const STRIPE_API_VERSION = "2026-05-27.dahlia" as Stripe.LatestApiVersion;

let stripeClient: Stripe | null = null;
let warnedMissingKey = false;

/**
 * Retorna o cliente Stripe configurado, ou null se a STRIPE_SECRET_KEY
 * ainda não foi definida no ambiente. Todas as rotas que dependem da
 * Stripe devem tratar o caso null retornando 503 com uma mensagem clara,
 * em vez de deixar a aplicação cair.
 */
export function getStripeClient(): Stripe | null {
  if (stripeClient) return stripeClient;

  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    if (!warnedMissingKey) {
      console.warn("[Stripe] STRIPE_SECRET_KEY não configurada. Rotas de pagamento responderão 503 até a chave ser definida.");
      warnedMissingKey = true;
    }
    return null;
  }

  stripeClient = new Stripe(key, {
    apiVersion: STRIPE_API_VERSION,
    appInfo: {
      name: "CyberPhone",
      version: "1.3.1",
    },
  });
  return stripeClient;
}

export const isStripeConfigured = (): boolean => !!process.env.STRIPE_SECRET_KEY;

/** Moeda de cobrança usada pela Stripe (AOA/Kwanza não é suportado pela Stripe). */
export const STRIPE_CHECKOUT_CURRENCY = "eur";

/** Taxa de conversão padrão (1 EUR = 1200 KZ). Sobrescrita por GlobalSettings.eurToKzRate quando definida pelo admin. */
export const DEFAULT_EUR_TO_KZ_RATE = 1200;

/** Converte um valor em Kwanzas para EUR usando a taxa fornecida (ou a padrão). */
export const kzToEur = (amountKz: number, eurToKzRate: number = DEFAULT_EUR_TO_KZ_RATE): number => {
  return amountKz / eurToKzRate;
};

/** Converte um valor em EUR para a menor unidade monetária aceite pela Stripe (cêntimos). */
export const eurToStripeAmount = (amountEur: number): number => {
  return Math.round(amountEur * 100);
};

/** Atalho: Kwanzas -> menor unidade da Stripe (cêntimos de EUR), já aplicando a taxa de conversão. */
export const kzToStripeAmount = (amountKz: number, eurToKzRate: number = DEFAULT_EUR_TO_KZ_RATE): number => {
  return eurToStripeAmount(kzToEur(amountKz, eurToKzRate));
};

export default Stripe;
