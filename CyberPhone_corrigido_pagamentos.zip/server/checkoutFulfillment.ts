import { Firestore } from "firebase-admin/firestore";
import { FieldValue } from "./firebaseAdmin";
import crypto from "crypto";

function generateId(): string {
  return crypto.randomUUID();
}

interface CheckoutCartItem {
  productId: string;
  quantity: number;
  selectedColor?: string;
  affiliateId?: string;
}

interface FulfillablePaymentIntent {
  id: string;
  userId: string; // buyerId
  amountKz: number;
  cartItems: CheckoutCartItem[];
  shippingAddress?: any;
  carrier?: { id: string; name: string };
  affiliateId?: string | null;
}

/**
 * Finaliza uma compra de carrinho já PAGA via Stripe.
 *
 * Importante: como o comprador pagou diretamente à Stripe (cartão), o saldo
 * da carteira do comprador NÃO é debitado aqui — apenas o vendedor e o
 * afiliado (se houver) recebem crédito em pendingBalance, replicando o
 * mesmo modelo de custódia (escrow) usado nas compras pagas com saldo.
 *
 * Esta função é chamada pelo webhook da Stripe (stripeRoutes.ts) depois
 * da transação que marca o PaymentIntent como SUCCEEDED, e por isso já
 * roda fora dessa transação principal — cada item processa sua própria
 * escrita para evitar um único `runTransaction` gigante com N produtos.
 */
export async function fulfillCartCheckout(adminDb: Firestore, intentData: FulfillablePaymentIntent) {
  const { id: intentId, userId: buyerId, cartItems, shippingAddress, carrier, affiliateId } = intentData;

  if (!cartItems || cartItems.length === 0) {
    console.warn("[CheckoutFulfillment] PaymentIntent sem itens de carrinho:", intentId);
    return;
  }

  // Idempotência: se este intent já foi processado (fulfillment concluído), não repetir.
  const fulfillmentMarkerRef = adminDb.collection("payment_intents").doc(intentId).collection("_meta").doc("fulfillment");
  const markerSnap = await fulfillmentMarkerRef.get();
  if (markerSnap.exists) {
    console.log("[CheckoutFulfillment] Intent já processado anteriormente, ignorando:", intentId);
    return;
  }

  const settingsSnap = await adminDb.collection("settings").doc("global").get();
  const platformTaxPercent = settingsSnap.exists ? (settingsSnap.data() as any)?.platformTax ?? 0.1 : 0.1;
  const platformTax = platformTaxPercent / 100 > 1 ? platformTaxPercent / 100 : platformTaxPercent; // tolera 0.1 (10%) ou 10 (10%) conforme guardado
  const batchTimestamp = Date.now();
  const createdSaleIds: string[] = [];

  for (const item of cartItems) {
    try {
      const productSnap = await adminDb.collection("products").doc(item.productId).get();
      if (!productSnap.exists) continue;
      const product = productSnap.data() as any;

      const storeSnap = await adminDb.collection("stores").doc(product.storeId).get();
      if (!storeSnap.exists) continue;
      const store = storeSnap.data() as any;
      const sellerId = store.userId;

      let unitPrice = product.price;
      if (item.selectedColor) {
        const matchedVariant = (product.variants || []).find(
          (v: any) => v.name === item.selectedColor || v.id === item.selectedColor
        );
        if (matchedVariant) unitPrice = matchedVariant.price;
      }

      const shippingCost = (product.type === "PHYSICAL" && !product.hasFreeShipping) ? (product.shippingFee || 0) : 0;
      const totalAmount = (unitPrice * item.quantity) + shippingCost;
      const saleId = generateId();

      const initialStatus = product.type === "PHYSICAL" ? "WAITLIST" : "DELIVERED";

      let sellerEarnings = totalAmount * (1 - platformTax);
      let affiliateEarnings = 0;
      const finalAffiliateId = item.affiliateId || affiliateId || null;

      if (finalAffiliateId && product.affiliateCommissionRate > 0) {
        affiliateEarnings = totalAmount * (product.affiliateCommissionRate / 100);
        sellerEarnings -= affiliateEarnings;
      }

      await adminDb.collection("sales").doc(saleId).set({
        id: saleId,
        productId: item.productId,
        buyerId,
        sellerId,
        affiliateUserId: finalAffiliateId || "",
        storeId: product.storeId,
        timestamp: batchTimestamp,
        status: initialStatus,
        shippingAddress: shippingAddress || null,
        saleAmount: totalAmount,
        sellerEarnings,
        affiliateEarnings,
        fundsReleased: false,
        carrierId: carrier?.id || "",
        carrierName: carrier?.name || shippingAddress?.carrierName || "",
        selectedVariant: item.selectedColor || "",
        paymentMethod: "stripe",
        paymentIntentRef: intentId,
      });
      createdSaleIds.push(saleId);

      await adminDb.collection("profiles").doc(sellerId).update({
        pendingBalance: FieldValue.increment(sellerEarnings),
        totalEarnings: FieldValue.increment(sellerEarnings),
      });
      await adminDb.collection("public_profiles").doc(sellerId).update({
        totalEarnings: FieldValue.increment(sellerEarnings),
      }).catch(() => { /* public_profiles pode não espelhar totalEarnings; ignorar se falhar */ });

      if (finalAffiliateId && affiliateEarnings > 0) {
        await adminDb.collection("profiles").doc(finalAffiliateId).update({
          pendingBalance: FieldValue.increment(affiliateEarnings),
          totalEarnings: FieldValue.increment(affiliateEarnings),
        });
      }

      const buyTxId = generateId();
      await adminDb.collection("transactions").doc(buyTxId).set({
        id: buyTxId,
        userId: buyerId,
        type: "PURCHASE",
        amount: -totalAmount,
        description: `Compra de produto: ${product.name || "Produto"} (Pago via cartão)`,
        timestamp: batchTimestamp,
        status: "COMPLETED",
      });

      await adminDb.collection("products").doc(item.productId).update({
        soldCount: FieldValue.increment(item.quantity),
      });
    } catch (itemError: any) {
      console.error(`[CheckoutFulfillment] Erro ao processar item ${item.productId} do intent ${intentId}:`, itemError.message);
      // Continua processando os demais itens do carrinho mesmo que um falhe;
      // o erro fica registrado para investigação manual.
      await adminDb.collection("checkout_fulfillment_errors").add({
        intentId,
        productId: item.productId,
        error: itemError.message,
        timestamp: Date.now(),
      }).catch(() => {});
    }
  }

  // Marca o intent como processado para garantir idempotência mesmo que a Stripe reenvie o webhook.
  await fulfillmentMarkerRef.set({
    processedAt: Date.now(),
    saleIds: createdSaleIds,
  });
}
