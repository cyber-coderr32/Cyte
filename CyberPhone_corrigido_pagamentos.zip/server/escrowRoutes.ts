import express, { Request, Response, Router } from "express";
import { getAdminDb, FieldValue } from "./firebaseAdmin";
import type { Firestore } from "firebase-admin/firestore";
import crypto from "crypto";

const router: Router = express.Router();

function generateId(): string {
  return crypto.randomUUID();
}

async function getOrderCancellationFeePercentage(adminDb: Firestore): Promise<number> {
  const snap = await adminDb.collection("settings").doc("global").get();
  const fee = snap.exists ? (snap.data() as any)?.orderCancellationFeePercentage : undefined;
  return typeof fee === "number" ? fee : 5;
}

/**
 * POST /api/wallet/orders/:saleId/cancel
 * O comprador cancela um pedido ainda não liberado ao vendedor. Reembolsa
 * o comprador (com taxa de cancelamento se já estava em processamento) e
 * reverte o pendingBalance do vendedor/afiliado.
 *
 * Body: { userId } — precisa ser o próprio comprador da venda.
 */
router.post("/orders/:saleId/cancel", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { saleId } = req.params;
    const { userId } = req.body || {};
    if (!userId) return res.status(400).json({ error: "userId é obrigatório." });

    const saleRef = adminDb.collection("sales").doc(saleId);
    const feePercentageDefault = await getOrderCancellationFeePercentage(adminDb);

    await adminDb.runTransaction(async (tx) => {
      const saleSnap = await tx.get(saleRef);
      if (!saleSnap.exists) throw new Error("Venda não encontrada.");
      const sale = saleSnap.data() as any;

      if (sale.buyerId !== userId) throw new Error("Apenas o comprador pode cancelar esta venda.");
      if (sale.status === "CANCELED") throw new Error("Venda já cancelada.");
      if (sale.fundsReleased) throw new Error("Não é possível cancelar um pedido cujos fundos já foram liberados.");

      const saleAmount = Number(sale.saleAmount) || 0;
      const sellerEarnings = Number(sale.sellerEarnings) || 0;
      const affiliateEarnings = Number(sale.affiliateEarnings) || 0;

      const isWaitlist = sale.status === "WAITLIST";
      const feePercentage = isWaitlist ? 0 : feePercentageDefault;
      const refundPercentage = (100 - feePercentage) / 100;
      const refundAmount = saleAmount * refundPercentage;
      const feeAmount = saleAmount - refundAmount;

      tx.update(saleRef, {
        status: "CANCELED",
        canceledAt: Date.now(),
        refundAmount,
        cancellationFee: feeAmount,
        updatedAt: Date.now(),
      });

      if (sellerEarnings > 0) {
        tx.update(adminDb.collection("profiles").doc(sale.sellerId), {
          pendingBalance: FieldValue.increment(-sellerEarnings),
          totalEarnings: FieldValue.increment(-sellerEarnings),
        });
      }
      if (sale.affiliateUserId && affiliateEarnings > 0) {
        tx.update(adminDb.collection("profiles").doc(sale.affiliateUserId), {
          pendingBalance: FieldValue.increment(-affiliateEarnings),
          totalEarnings: FieldValue.increment(-affiliateEarnings),
        });
      }

      tx.update(adminDb.collection("profiles").doc(sale.buyerId), { balance: FieldValue.increment(refundAmount) });
      tx.update(adminDb.collection("public_profiles").doc(sale.buyerId), { balance: FieldValue.increment(refundAmount) });

      const transId = generateId();
      tx.set(adminDb.collection("transactions").doc(transId), {
        id: transId,
        userId: sale.buyerId,
        type: "REFUND",
        amount: refundAmount,
        description: `Reembolso de pedido #${String(sale.id || saleId).slice(-8).toUpperCase()} (com taxa de renúncia de ${feePercentage}%)`,
        timestamp: Date.now(),
        status: "COMPLETED",
      });
    });

    res.json({ success: true });
  } catch (error: any) {
    console.error("[Escrow] Erro ao cancelar pedido:", error.message);
    res.status(400).json({ error: error.message || "Falha ao cancelar o pedido." });
  }
});

/**
 * POST /api/wallet/orders/:saleId/release-funds
 * Libera os fundos em custódia (pendingBalance) para o vendedor e afiliado,
 * movendo-os para o saldo disponível (balance). Tipicamente chamado quando
 * o comprador confirma o recebimento do produto.
 */
router.post("/orders/:saleId/release-funds", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { saleId } = req.params;
    const saleRef = adminDb.collection("sales").doc(saleId);

    await adminDb.runTransaction(async (tx) => {
      const saleSnap = await tx.get(saleRef);
      if (!saleSnap.exists) throw new Error("Venda não encontrada.");
      const sale = saleSnap.data() as any;

      if (sale.fundsReleased) {
        console.log("[Escrow] Fundos já liberados para a venda:", saleId);
        return;
      }

      const sellerEarning = Number(sale.sellerEarnings) || 0;
      const affiliateEarning = Number(sale.affiliateEarnings) || 0;

      if (sellerEarning > 0) {
        tx.update(adminDb.collection("profiles").doc(sale.sellerId), {
          balance: FieldValue.increment(sellerEarning),
          pendingBalance: FieldValue.increment(-sellerEarning),
        });
        tx.update(adminDb.collection("public_profiles").doc(sale.sellerId), { balance: FieldValue.increment(sellerEarning) });

        const sTransId = generateId();
        tx.set(adminDb.collection("transactions").doc(sTransId), {
          id: sTransId,
          userId: sale.sellerId,
          type: "SALE",
          amount: sellerEarning,
          description: `Fundo liberado da venda: ${saleId}`,
          timestamp: Date.now(),
          status: "COMPLETED",
        });
      }

      if (affiliateEarning > 0 && sale.affiliateUserId) {
        tx.update(adminDb.collection("profiles").doc(sale.affiliateUserId), {
          balance: FieldValue.increment(affiliateEarning),
          pendingBalance: FieldValue.increment(-affiliateEarning),
        });
        tx.update(adminDb.collection("public_profiles").doc(sale.affiliateUserId), { balance: FieldValue.increment(affiliateEarning) });

        const aTransId = generateId();
        tx.set(adminDb.collection("transactions").doc(aTransId), {
          id: aTransId,
          userId: sale.affiliateUserId,
          type: "SALE",
          amount: affiliateEarning,
          description: `Comissão liberada da venda: ${saleId}`,
          timestamp: Date.now(),
          status: "COMPLETED",
        });
      }

      tx.update(saleRef, { fundsReleased: true, status: "COMPLETED", updatedAt: Date.now() });
    });

    res.json({ success: true });
  } catch (error: any) {
    console.error("[Escrow] Erro ao liberar fundos:", error.message);
    res.status(400).json({ error: error.message || "Falha ao liberar os fundos." });
  }
});

/**
 * POST /api/wallet/orders/:saleId/refund
 * Cancela e reembolsa totalmente uma venda cujos fundos ainda não foram
 * liberados (caminho usado por disputas/decisão administrativa direta).
 */
router.post("/orders/:saleId/refund", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { saleId } = req.params;
    const saleRef = adminDb.collection("sales").doc(saleId);

    await adminDb.runTransaction(async (tx) => {
      const saleSnap = await tx.get(saleRef);
      if (!saleSnap.exists) throw new Error("Venda não encontrada.");
      const sale = saleSnap.data() as any;

      if (sale.fundsReleased) {
        throw new Error("Fundos já foram liberados para o vendedor. Não é possível estornar automaticamente.");
      }

      tx.update(adminDb.collection("profiles").doc(sale.buyerId), { balance: FieldValue.increment(sale.saleAmount) });
      tx.update(adminDb.collection("public_profiles").doc(sale.buyerId), { balance: FieldValue.increment(sale.saleAmount) });

      const transId = generateId();
      tx.set(adminDb.collection("transactions").doc(transId), {
        id: transId,
        userId: sale.buyerId,
        type: "DEPOSIT",
        amount: sale.saleAmount,
        description: `Estorno da compra: ${saleId}`,
        timestamp: Date.now(),
        status: "COMPLETED",
      });

      const sellerEarnings = Number(sale.sellerEarnings) || 0;
      const affiliateEarnings = Number(sale.affiliateEarnings) || 0;

      if (sellerEarnings > 0) {
        tx.update(adminDb.collection("profiles").doc(sale.sellerId), {
          pendingBalance: FieldValue.increment(-sellerEarnings),
          totalEarnings: FieldValue.increment(-sellerEarnings),
        });
      }
      if (sale.affiliateUserId && affiliateEarnings > 0) {
        tx.update(adminDb.collection("profiles").doc(sale.affiliateUserId), {
          pendingBalance: FieldValue.increment(-affiliateEarnings),
          totalEarnings: FieldValue.increment(-affiliateEarnings),
        });
      }

      tx.update(saleRef, {
        status: "CANCELED",
        updatedAt: Date.now(),
        refundedAt: Date.now(),
        refundAmount: sale.saleAmount,
      });
    });

    res.json({ success: true });
  } catch (error: any) {
    console.error("[Escrow] Erro ao reembolsar:", error.message);
    res.status(400).json({ error: error.message || "Falha ao reembolsar a compra." });
  }
});

/**
 * POST /api/wallet/orders/:saleId/return-decision
 * Decisão (aprovação/rejeição) de um pedido de devolução. Em caso de
 * aprovação, reembolsa o comprador e reverte os ganhos do vendedor/afiliado
 * — descontando do saldo disponível se já tinham sido liberados, ou do
 * pendingBalance caso ainda estivessem em custódia.
 *
 * Body: { decision: 'APPROVED' | 'REJECTED', sellerExplanation? }
 */
router.post("/orders/:saleId/return-decision", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { saleId } = req.params;
    const { decision, sellerExplanation } = req.body || {};
    if (decision !== "APPROVED" && decision !== "REJECTED") {
      return res.status(400).json({ error: "decision deve ser 'APPROVED' ou 'REJECTED'." });
    }

    const saleRef = adminDb.collection("sales").doc(saleId);

    await adminDb.runTransaction(async (tx) => {
      const saleSnap = await tx.get(saleRef);
      if (!saleSnap.exists) throw new Error("Venda não encontrada.");
      const sale = saleSnap.data() as any;

      if (decision === "REJECTED") {
        tx.update(saleRef, {
          returnStatus: "REJECTED",
          refundStatus: "DENIED",
          sellerExplanation: sellerExplanation || "",
          updatedAt: Date.now(),
        });
        return;
      }

      const saleAmount = Number(sale.saleAmount) || 0;
      const sellerEarnings = Number(sale.sellerEarnings) || 0;
      const affiliateEarnings = Number(sale.affiliateEarnings) || 0;

      tx.update(adminDb.collection("profiles").doc(sale.buyerId), { balance: FieldValue.increment(saleAmount) });
      tx.update(adminDb.collection("public_profiles").doc(sale.buyerId), { balance: FieldValue.increment(saleAmount) });

      const refundTransId = generateId();
      tx.set(adminDb.collection("transactions").doc(refundTransId), {
        id: refundTransId,
        userId: sale.buyerId,
        type: "REFUND",
        amount: saleAmount,
        description: `Reembolso de devolução aceita: Pedido #${String(sale.id || saleId).slice(-8).toUpperCase()}`,
        timestamp: Date.now(),
        status: "COMPLETED",
      });

      if (sale.fundsReleased) {
        if (sellerEarnings > 0) {
          tx.update(adminDb.collection("profiles").doc(sale.sellerId), {
            balance: FieldValue.increment(-sellerEarnings),
            totalEarnings: FieldValue.increment(-sellerEarnings),
          });
          tx.update(adminDb.collection("public_profiles").doc(sale.sellerId), { balance: FieldValue.increment(-sellerEarnings) });

          const chargebackTransId = generateId();
          tx.set(adminDb.collection("transactions").doc(chargebackTransId), {
            id: chargebackTransId,
            userId: sale.sellerId,
            type: "WITHDRAWAL",
            amount: sellerEarnings,
            description: `Debito de reembolso aprovado (devolução): Pedido #${String(sale.id || saleId).slice(-8).toUpperCase()}`,
            timestamp: Date.now(),
            status: "COMPLETED",
          });
        }
        if (sale.affiliateUserId && affiliateEarnings > 0) {
          tx.update(adminDb.collection("profiles").doc(sale.affiliateUserId), {
            balance: FieldValue.increment(-affiliateEarnings),
            totalEarnings: FieldValue.increment(-affiliateEarnings),
          });
          tx.update(adminDb.collection("public_profiles").doc(sale.affiliateUserId), { balance: FieldValue.increment(-affiliateEarnings) });
        }
      } else {
        if (sellerEarnings > 0) {
          tx.update(adminDb.collection("profiles").doc(sale.sellerId), {
            pendingBalance: FieldValue.increment(-sellerEarnings),
            totalEarnings: FieldValue.increment(-sellerEarnings),
          });
        }
        if (sale.affiliateUserId && affiliateEarnings > 0) {
          tx.update(adminDb.collection("profiles").doc(sale.affiliateUserId), {
            pendingBalance: FieldValue.increment(-affiliateEarnings),
            totalEarnings: FieldValue.increment(-affiliateEarnings),
          });
        }
      }

      tx.update(saleRef, {
        status: "CANCELED",
        returnStatus: "APPROVED",
        refundStatus: "REFUNDED",
        refundAmount: saleAmount,
        refundTimestamp: Date.now(),
        sellerExplanation: sellerExplanation || "",
        updatedAt: Date.now(),
      });
    });

    await adminDb.collection("system_logs").add({
      action: decision === "APPROVED" ? "RETURN_APPROVED" : "RETURN_REJECTED",
      details: `Devolução ${decision === "APPROVED" ? "aprovada e reembolsada" : "rejeitada pelo vendedor"} para a venda ${saleId}.`,
      timestamp: Date.now(),
    }).catch(() => {});

    res.json({ success: true });
  } catch (error: any) {
    console.error("[Escrow] Erro ao processar decisão de devolução:", error.message);
    res.status(400).json({ error: error.message || "Falha ao processar a decisão de devolução." });
  }
});

export default router;
