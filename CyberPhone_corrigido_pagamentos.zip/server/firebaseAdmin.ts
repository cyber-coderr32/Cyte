import admin from "firebase-admin";
import { getFirestore, Firestore } from "firebase-admin/firestore";

/**
 * Inicialização do Firebase Admin SDK (uso exclusivo do servidor).
 *
 * SEGURANÇA: O Admin SDK ignora completamente as firestore.rules — ele tem
 * acesso administrativo total ao banco de dados. Por isso:
 *   1. Este ficheiro NUNCA deve ser importado por código que rode no navegador.
 *   2. A credencial (Service Account) vem apenas de variável de ambiente,
 *      nunca deve ser commitada no repositório.
 *
 * Variável de ambiente esperada:
 *   FIREBASE_SERVICE_ACCOUNT_JSON = conteúdo integral do JSON da Service Account
 *   (Firebase Console > Configurações do projeto > Contas de serviço > Gerar nova chave privada)
 */

function loadServiceAccount(): admin.ServiceAccount | null {
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    return parsed as admin.ServiceAccount;
  } catch (err) {
    console.error("[FirebaseAdmin] FIREBASE_SERVICE_ACCOUNT_JSON inválido (não é um JSON válido):", (err as Error).message);
    return null;
  }
}

let adminApp: admin.app.App | null = null;
let adminDb: Firestore | null = null;

export function getAdminApp(): admin.app.App | null {
  if (adminApp) return adminApp;

  if (admin.apps.length > 0) {
    adminApp = admin.apps[0] as admin.app.App;
    return adminApp;
  }

  const serviceAccount = loadServiceAccount();
  if (!serviceAccount) {
    console.warn("[FirebaseAdmin] FIREBASE_SERVICE_ACCOUNT_JSON não configurada. Rotas que dependem do Admin SDK (pagamentos, Connect) responderão com erro 503 até a credencial ser definida.");
    return null;
  }

  try {
    adminApp = admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      projectId: (serviceAccount as any).projectId || (serviceAccount as any).project_id,
    });
    console.log("✅ [FirebaseAdmin] Inicializado com sucesso. Projeto:", (serviceAccount as any).projectId || (serviceAccount as any).project_id);
    return adminApp;
  } catch (err) {
    console.error("❌ [FirebaseAdmin] Falha ao inicializar:", (err as Error).message);
    return null;
  }
}

export function getAdminDb(): Firestore | null {
  if (adminDb) return adminDb;
  const app = getAdminApp();
  if (!app) return null;

  const databaseId = process.env.VITE_FIREBASE_FIRESTORE_DATABASE_ID;
  try {
    adminDb = (databaseId && databaseId !== "(default)")
      ? getFirestore(app, databaseId)
      : getFirestore(app);
    if (databaseId && databaseId !== "(default)") {
      console.log("ℹ️ [FirebaseAdmin] Usando database nomeada:", databaseId);
    }
    return adminDb;
  } catch (err) {
    console.error("❌ [FirebaseAdmin] Falha ao obter instância do Firestore:", (err as Error).message);
    return null;
  }
}

export const FieldValue = admin.firestore.FieldValue;

export default admin;
