import express, { Request, Response, Router } from "express";
import { getAdminDb, FieldValue } from "./firebaseAdmin";
import crypto from "crypto";

const router: Router = express.Router();

function generateId(): string {
  return crypto.randomUUID();
}

/**
 * Catálogo de "taxas de plataforma" que debitam saldo do próprio usuário em
 * troca de um benefício imediato (impulsionar post/produto, investir em
 * anúncio, pagar verificação, criar grupo/loja). Todas seguem o mesmo
 * padrão: validar saldo -> debitar -> registar transação -> aplicar o
 * efeito (ex: marcar post como promovido). Centralizamos aqui em vez de
 * criar 8 rotas quase identicas.
 */
type FeeType =
  | "BOOST_POST"
  | "PROMOTE_PRODUCT"
  | "PROMOTE_CAROUSEL"
  | "AD_INVESTMENT"
  | "AD_RENEWAL"
  | "VERIFICATION_FEE"
  | "GROUP_CREATION_FEE"
  | "STORE_VERIFICATION_FEE";

const FEE_DESCRIPTIONS: Record<FeeType, (ctx: any) => string> = {
  BOOST_POST: (ctx) => `Boost de publicação (Lance: ${ctx.amount.toFixed(2)} KZ) - ${ctx.days} dias`,
  PROMOTE_PRODUCT: (ctx) => `Promoção de Produto (${ctx.days} dias) - ID: ${ctx.targetId}`,
  PROMOTE_CAROUSEL: (ctx) => `Promoção no Carrossel (${ctx.days} dias) - ID: ${ctx.targetId}`,
  AD_INVESTMENT: (ctx) => `Ad: ${ctx.title || ctx.targetId}`,
  AD_RENEWAL: (ctx) => `Renovação Automática de Anúncio: ${ctx.title || ctx.targetId}`,
  VERIFICATION_FEE: () => `Taxa de Verificação de Identidade (Selo Azul)`,
  GROUP_CREATION_FEE: (ctx) => `Criação de Comunidade: ${ctx.title || ctx.targetId}`,
  STORE_VERIFICATION_FEE: () => `Taxa de Verificação de Loja`,
};

/**
 * POST /api/wallet/charge-fee
 *
 * Debita uma taxa de plataforma do saldo do próprio usuário, dentro de uma
 * transação atómica que valida o saldo no momento exato do débito (evita
 * condições de corrida em que duas requisições simultâneas debitariam
 * saldo insuficiente).
 *
 * Body: { userId, amount, type: FeeType, days?, targetId?, title? }
 */
router.post("/charge-fee", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { userId, amount, type, days, targetId, title } = req.body || {};

    if (!userId || typeof userId !== "string") {
      return res.status(400).json({ error: "userId é obrigatório." });
    }
    if (typeof amount !== "number" || amount <= 0) {
      return res.status(400).json({ error: "amount deve ser um número positivo." });
    }
    if (!type || !(type in FEE_DESCRIPTIONS)) {
      return res.status(400).json({ error: "type de taxa inválido." });
    }

    const userSnap = await adminDb.collection("profiles").doc(userId).get();
    if (!userSnap.exists) return res.status(404).json({ error: "Usuário não encontrado." });
    if ((userSnap.data() as any)?.isFrozen) {
      return res.status(403).json({ error: "Esta conta está temporariamente bloqueada para transações financeiras." });
    }

    const txId = generateId();

    await adminDb.runTransaction(async (tx) => {
      const freshSnap = await tx.get(adminDb.collection("profiles").doc(userId));
      const freshBalance = (freshSnap.data() as any)?.balance || 0;
      if (freshBalance < amount) {
        throw new Error("Saldo insuficiente para esta operação.");
      }

      tx.update(adminDb.collection("profiles").doc(userId), { balance: FieldValue.increment(-amount) });
      tx.update(adminDb.collection("public_profiles").doc(userId), { balance: FieldValue.increment(-amount) });

      tx.set(adminDb.collection("transactions").doc(txId), {
        id: txId,
        userId,
        amount: -amount,
        type: type === "VERIFICATION_FEE" || type === "GROUP_CREATION_FEE" || type === "STORE_VERIFICATION_FEE" ? "PLATFORM_FEE" : "BOOST",
        description: FEE_DESCRIPTIONS[type as FeeType]({ amount, days, targetId, title }),
        timestamp: Date.now(),
        status: "COMPLETED",
      });
    });

    res.json({ success: true, transactionId: txId });
  } catch (error: any) {
    console.error("[WalletFee] Erro ao debitar taxa:", error.message);
    res.status(400).json({ error: error.message || "Falha ao processar a taxa." });
  }
});

/**
 * POST /api/wallet/transfer
 * Transferência ponto-a-ponto entre usuários (doações). Debita 'from',
 * credita 'to', dentro de uma única transação atómica.
 *
 * Body: { fromUserId, toUserId, amount, description? }
 */
router.post("/transfer", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { fromUserId, toUserId, amount, description } = req.body || {};

    if (!fromUserId || !toUserId) {
      return res.status(400).json({ error: "fromUserId e toUserId são obrigatórios." });
    }
    if (typeof amount !== "number" || amount <= 0) {
      return res.status(400).json({ error: "amount deve ser um número positivo." });
    }

    const fromSnap = await adminDb.collection("profiles").doc(fromUserId).get();
    if (!fromSnap.exists) return res.status(404).json({ error: "Usuário remetente não encontrado." });
    if ((fromSnap.data() as any)?.isFrozen) {
      return res.status(403).json({ error: "Esta conta está temporariamente bloqueada para transações financeiras." });
    }
    const toSnap = await adminDb.collection("profiles").doc(toUserId).get();
    if (!toSnap.exists) return res.status(404).json({ error: "Usuário destinatário não encontrado." });

    const txId = generateId();

    await adminDb.runTransaction(async (tx) => {
      const freshFromSnap = await tx.get(adminDb.collection("profiles").doc(fromUserId));
      const freshBalance = (freshFromSnap.data() as any)?.balance || 0;
      if (freshBalance < amount) {
        throw new Error("Saldo insuficiente para esta transferência.");
      }

      tx.update(adminDb.collection("profiles").doc(fromUserId), { balance: FieldValue.increment(-amount) });
      tx.update(adminDb.collection("profiles").doc(toUserId), { balance: FieldValue.increment(amount) });
      tx.update(adminDb.collection("public_profiles").doc(fromUserId), { balance: FieldValue.increment(-amount) });
      tx.update(adminDb.collection("public_profiles").doc(toUserId), { balance: FieldValue.increment(amount) });

      tx.set(adminDb.collection("transactions").doc(txId), {
        id: txId,
        userId: fromUserId,
        amount: -amount,
        type: "DONATION",
        description: description || `Doação para usuário ${toUserId}`,
        timestamp: Date.now(),
        status: "COMPLETED",
      });
    });

    res.json({ success: true, transactionId: txId });
  } catch (error: any) {
    console.error("[WalletTransfer] Erro ao transferir:", error.message);
    res.status(400).json({ error: error.message || "Falha ao processar a transferência." });
  }
});

/**
 * POST /api/wallet/admin-adjust
 * Ajuste manual de saldo feito por um administrador (painel admin).
 * Body: { adminId, targetUserId, delta } — delta é somado ao saldo atual
 * (pode ser negativo para descontar).
 */
router.post("/admin-adjust", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { adminId, targetUserId, delta } = req.body || {};
    if (!adminId || !targetUserId || typeof delta !== "number") {
      return res.status(400).json({ error: "adminId, targetUserId e delta são obrigatórios." });
    }

    const adminSnap = await adminDb.collection("profiles").doc(adminId).get();
    if (!adminSnap.exists || !(adminSnap.data() as any)?.isAdmin) {
      return res.status(403).json({ error: "Apenas administradores podem ajustar saldos manualmente." });
    }

    const targetRef = adminDb.collection("profiles").doc(targetUserId);
    const targetSnap = await targetRef.get();
    if (!targetSnap.exists) return res.status(404).json({ error: "Usuário não encontrado." });

    await targetRef.update({ balance: FieldValue.increment(delta) });
    await adminDb.collection("public_profiles").doc(targetUserId).update({ balance: FieldValue.increment(delta) }).catch(() => {});

    const txId = generateId();
    await adminDb.collection("transactions").doc(txId).set({
      id: txId,
      userId: targetUserId,
      amount: delta,
      type: delta >= 0 ? "DEPOSIT" : "WITHDRAWAL",
      description: `Ajuste manual de saldo pelo administrador`,
      timestamp: Date.now(),
      status: "COMPLETED",
    });

    res.json({ success: true });
  } catch (error: any) {
    console.error("[WalletAdminAdjust] Erro ao ajustar saldo:", error.message);
    res.status(500).json({ error: error.message || "Falha ao ajustar o saldo." });
  }
});

/**
 * POST /api/wallet/freeze-accounts
 *
 * Congela uma ou mais contas após deteção de fraude pelo sistema Sentinela
 * AI no cliente (ex: conteúdo de chat suspeito). O campo isFrozen não pode
 * mais ser escrito diretamente pelo cliente, por isso esta rota existe como
 * o único caminho legítimo para essa ação de segurança.
 *
 * Body: { userIds: string[], reason? }
 */
router.post("/freeze-accounts", async (req: Request, res: Response) => {
  const adminDb = getAdminDb();
  if (!adminDb) return res.status(503).json({ error: "Serviço indisponível." });

  try {
    const { userIds, reason } = req.body || {};
    if (!Array.isArray(userIds) || userIds.length === 0) {
      return res.status(400).json({ error: "userIds é obrigatório e não pode estar vazio." });
    }

    const batch = adminDb.batch();
    for (const uid of userIds) {
      batch.update(adminDb.collection("profiles").doc(uid), { isFrozen: true });
    }
    await batch.commit();

    await adminDb.collection("system_logs").add({
      action: "SENTINEL_FREEZE",
      details: `Contas congeladas pelo Sentinela AI: ${userIds.join(", ")}. Motivo: ${reason || "Atividade suspeita detectada"}`,
      timestamp: Date.now(),
    }).catch(() => {});

    res.json({ success: true });
  } catch (error: any) {
    console.error("[WalletFreeze] Erro ao congelar contas:", error.message);
    res.status(500).json({ error: error.message || "Falha ao congelar as contas." });
  }
});

export default router;
