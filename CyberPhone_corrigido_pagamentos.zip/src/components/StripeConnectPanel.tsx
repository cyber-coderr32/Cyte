import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  BuildingLibraryIcon,
  CheckCircleIcon,
  ExclamationCircleIcon,
  ClockIcon,
  CreditCardIcon,
  ArrowTopRightOnSquareIcon,
  SparklesIcon,
} from '@heroicons/react/24/outline';
import { User } from '../types';
import {
  startStripeConnectOnboarding,
  getStripeConnectStatus,
  requestVirtualCard,
  listVirtualCards,
  ConnectStatusResult,
  VirtualCardResult,
} from '../services/paymentService';
import { useDialog } from '../services/DialogContext';

interface StripeConnectPanelProps {
  currentUser: User;
}

const STATUS_LABELS: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  NOT_STARTED: { label: 'Não iniciado', color: 'text-gray-400', icon: ClockIcon },
  INFO_REQUIRED: { label: 'Dados pendentes', color: 'text-amber-500', icon: ExclamationCircleIcon },
  PENDING_REVIEW: { label: 'Em análise pela Stripe', color: 'text-amber-500', icon: ClockIcon },
  ACTIVE: { label: 'Conta ativa', color: 'text-emerald-500', icon: CheckCircleIcon },
  RESTRICTED: { label: 'Restrita', color: 'text-red-500', icon: ExclamationCircleIcon },
  REJECTED: { label: 'Rejeitada pela Stripe', color: 'text-red-500', icon: ExclamationCircleIcon },
};

/**
 * Painel de configuração bancária (Stripe Connect Custom) e cartão virtual
 * (Stripe Issuing). Permite ao usuário iniciar/retomar o onboarding bancário
 * e, uma vez com a conta ativa, solicitar um cartão virtual para gastar o
 * saldo de vendas.
 */
const StripeConnectPanel: React.FC<StripeConnectPanelProps> = ({ currentUser }) => {
  const { t } = useTranslation();
  const { showAlert } = useDialog();
  const [status, setStatus] = useState<ConnectStatusResult | null>(null);
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [onboarding, setOnboarding] = useState(false);
  const [cards, setCards] = useState<VirtualCardResult[]>([]);
  const [requestingCard, setRequestingCard] = useState(false);

  const refreshStatus = async () => {
    setLoadingStatus(true);
    try {
      const result = await getStripeConnectStatus(currentUser.id);
      setStatus(result);
      if (result.status === 'ACTIVE') {
        const cardList = await listVirtualCards(currentUser.id);
        setCards(cardList);
      }
    } catch (err: any) {
      console.error('Erro ao consultar status Connect:', err.message);
    } finally {
      setLoadingStatus(false);
    }
  };

  useEffect(() => {
    refreshStatus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleStartOnboarding = async () => {
    setOnboarding(true);
    try {
      const result = await startStripeConnectOnboarding(currentUser.id, currentUser.email);
      window.location.href = result.url;
    } catch (err: any) {
      showAlert(err.message || 'Falha ao iniciar a configuração bancária.', { type: 'error' });
      setOnboarding(false);
    }
  };

  const handleRequestCard = async () => {
    setRequestingCard(true);
    try {
      const card = await requestVirtualCard({
        userId: currentUser.id,
        name: `${currentUser.firstName} ${currentUser.lastName}`,
        email: currentUser.email,
        billingAddress: {
          line1: currentUser.address || 'N/A',
          city: currentUser.country || 'N/A',
          postal_code: '0000',
          country: status?.bankAccountCountry || 'PT',
        },
      });
      setCards((prev) => [...prev, card]);
      showAlert('Cartão virtual emitido com sucesso!', { type: 'success' });
    } catch (err: any) {
      showAlert(err.message || 'Falha ao solicitar o cartão virtual.', { type: 'error' });
    } finally {
      setRequestingCard(false);
    }
  };

  const statusInfo = STATUS_LABELS[status?.status || 'NOT_STARTED'];
  const StatusIcon = statusInfo.icon;

  return (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-4xl font-black dark:text-white tracking-tighter">{t('payments_and_banking') || 'Pagamentos & Conta Bancária'}</h2>

      <div className="bg-white dark:bg-white/5 rounded-[2.5rem] p-8 border border-gray-100 dark:border-white/10 shadow-sm">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-14 h-14 bg-brand/10 rounded-2xl flex items-center justify-center shrink-0">
            <BuildingLibraryIcon className="w-7 h-7 text-brand" />
          </div>
          <div>
            <h3 className="font-black text-sm uppercase tracking-tight dark:text-white">{t('bank_account_iban') || 'Conta Bancária (IBAN)'}</h3>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wide">{t('receive_earnings_directly') || 'Receba seus ganhos de vendas diretamente'}</p>
          </div>
        </div>

        {loadingStatus ? (
          <div className="flex items-center justify-center py-8">
            <div className="w-6 h-6 border-3 border-brand border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <>
            <div className="flex items-center gap-3 bg-gray-50 dark:bg-white/5 rounded-2xl p-4 mb-4">
              <StatusIcon className={`w-5 h-5 shrink-0 ${statusInfo.color}`} />
              <span className={`text-xs font-black uppercase tracking-wide ${statusInfo.color}`}>{statusInfo.label}</span>
            </div>

            {status?.bankAccountLast4 && (
              <p className="text-xs text-gray-400 font-medium mb-4 px-1">
                {t('bank_account_ending') || 'Conta terminada em'} •••• {status.bankAccountLast4}
              </p>
            )}

            {(status?.status === 'NOT_STARTED' || status?.status === 'INFO_REQUIRED' || status?.status === 'REJECTED') && (
              <button
                onClick={handleStartOnboarding}
                disabled={onboarding}
                className="w-full bg-brand text-white py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-lg shadow-brand/20 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {onboarding ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    {status?.status === 'NOT_STARTED' ? (t('setup_bank_account') || 'Configurar Conta Bancária') : (t('continue_setup') || 'Continuar Configuração')}
                    <ArrowTopRightOnSquareIcon className="w-4 h-4" />
                  </>
                )}
              </button>
            )}

            {status?.status === 'PENDING_REVIEW' && (
              <p className="text-xs text-amber-600 font-medium text-center py-2">
                {t('pending_review_desc') || 'Sua conta está sendo revisada pela Stripe. Isso pode levar alguns dias úteis.'}
              </p>
            )}
          </>
        )}
      </div>

      {status?.status === 'ACTIVE' && (
        <div className="bg-white dark:bg-white/5 rounded-[2.5rem] p-8 border border-gray-100 dark:border-white/10 shadow-sm">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 bg-gray-900 dark:bg-white/10 rounded-2xl flex items-center justify-center shrink-0">
              <CreditCardIcon className="w-7 h-7 text-white" />
            </div>
            <div>
              <h3 className="font-black text-sm uppercase tracking-tight dark:text-white">{t('virtual_card') || 'Cartão Virtual'}</h3>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wide">{t('spend_your_earnings') || 'Gaste seus ganhos diretamente'}</p>
            </div>
          </div>

          {cards.length === 0 ? (
            <button
              onClick={handleRequestCard}
              disabled={requestingCard}
              className="w-full bg-gray-900 dark:bg-white text-white dark:text-black py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {requestingCard ? (
                <div className="w-4 h-4 border-2 border-white dark:border-black border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <SparklesIcon className="w-4 h-4" />
                  {t('request_virtual_card') || 'Solicitar Cartão Virtual'}
                </>
              )}
            </button>
          ) : (
            <div className="space-y-3">
              {cards.map((card) => (
                <div key={card.id} className="bg-gradient-to-br from-gray-900 to-gray-700 dark:from-white/10 dark:to-white/5 rounded-3xl p-6 text-white">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/60 mb-2">{card.brand.toUpperCase()}</p>
                  <p className="text-lg font-black tracking-widest mb-4">•••• •••• •••• {card.last4}</p>
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-white/60">{String(card.expMonth).padStart(2, '0')}/{card.expYear}</span>
                    <span className={`font-black uppercase ${card.status === 'ACTIVE' ? 'text-emerald-400' : 'text-gray-400'}`}>{card.status}</span>
                  </div>
                </div>
              ))}
              <p className="text-[10px] text-gray-400 font-medium text-center px-2">
                {t('virtual_card_details_desc') || 'Por segurança, os dados completos do cartão (número e CVC) ficam disponíveis apenas no painel oficial da Stripe.'}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default StripeConnectPanel;
