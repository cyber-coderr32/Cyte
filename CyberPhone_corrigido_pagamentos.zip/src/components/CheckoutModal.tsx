import React, { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { loadStripe, type Stripe as StripeJs } from '@stripe/stripe-js';
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from '@stripe/react-stripe-js';
import {
  XMarkIcon,
  CreditCardIcon,
  CheckCircleIcon,
  ExclamationCircleIcon,
  BanknotesIcon,
  CurrencyDollarIcon,
} from '@heroicons/react/24/outline';
import { CartItem, PaymentMethod, ShippingAddress, User } from '../types';
import { createStripePaymentIntent, PAYMENT_PROVIDERS } from '../services/paymentService';

// O carregamento da Stripe.js só acontece quando este modal é de fato aberto,
// e a instância é cacheada em módulo para não recarregar o script a cada abertura.
let stripePromise: Promise<StripeJs | null> | null = null;
function getStripeJs(): Promise<StripeJs | null> {
  const publishableKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY as string | undefined;
  if (!publishableKey) {
    console.warn('[CheckoutModal] VITE_STRIPE_PUBLISHABLE_KEY não configurada.');
    return Promise.resolve(null);
  }
  if (!stripePromise) {
    stripePromise = loadStripe(publishableKey);
  }
  return stripePromise;
}

export interface CheckoutModalProps {
  currentUser: User;
  amountKz: number;
  purpose: 'WALLET_DEPOSIT' | 'CART_CHECKOUT';
  cartItems?: CartItem[];
  shippingAddress?: ShippingAddress;
  carrier?: { id: string; name: string };
  affiliateId?: string | null;
  onClose: () => void;
  onSuccess: () => void;
}

/**
 * Modal de checkout multi-método. Mostra o seletor (Stripe / KZ / Cripto) e,
 * quando Stripe é escolhido, monta o formulário de cartão via Stripe Elements.
 * KZ e Cripto aparecem como "Em breve" até que as respetivas APIs existam —
 * a estrutura de UI e o contrato de dados já estão prontos para serem ligados.
 */
const CheckoutModal: React.FC<CheckoutModalProps> = ({
  currentUser,
  amountKz,
  purpose,
  cartItems,
  shippingAddress,
  carrier,
  affiliateId,
  onClose,
  onSuccess,
}) => {
  const { t } = useTranslation();
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('stripe');
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [intentId, setIntentId] = useState<string | null>(null);
  const [amountEur, setAmountEur] = useState<number | null>(null);
  const [loadingIntent, setLoadingIntent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (selectedMethod !== 'stripe') return;
    let cancelled = false;
    setLoadingIntent(true);
    setError(null);

    createStripePaymentIntent({
      userId: currentUser.id,
      amountKz,
      purpose,
      cartItems,
      shippingAddress,
      carrier,
      affiliateId,
    })
      .then((res) => {
        if (cancelled) return;
        setClientSecret(res.clientSecret);
        setIntentId(res.intentId);
        setAmountEur(res.amountEur);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoadingIntent(false);
      });

    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMethod]);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white dark:bg-darkcard w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        <div className="px-8 py-6 border-b border-gray-100 dark:border-white/10 flex items-center justify-between shrink-0">
          <h3 className="text-sm font-black uppercase tracking-widest dark:text-white">
            {t('choose_payment_method') || 'Escolher Método de Pagamento'}
          </h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-white/10 rounded-full transition-colors">
            <XMarkIcon className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="overflow-y-auto p-8 space-y-6">
          <div className="bg-gray-50 dark:bg-white/5 rounded-3xl p-6 text-center">
            <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">
              {t('total_to_pay') || 'Total a pagar'}
            </p>
            <p className="text-3xl font-black text-brand">KZ {amountKz.toLocaleString()}</p>
          </div>

          <div className="space-y-3">
            {PAYMENT_PROVIDERS.map((provider) => (
              <button
                key={provider.id}
                onClick={() => provider.enabled && setSelectedMethod(provider.id)}
                disabled={!provider.enabled}
                className={`w-full flex items-center justify-between p-5 rounded-3xl border-2 transition-all text-left ${
                  selectedMethod === provider.id && provider.enabled
                    ? 'border-brand bg-brand/5'
                    : 'border-gray-100 dark:border-white/10'
                } ${!provider.enabled ? 'opacity-50 cursor-not-allowed' : 'active:scale-[0.98]'}`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${
                    selectedMethod === provider.id && provider.enabled ? 'bg-brand text-white' : 'bg-gray-100 dark:bg-white/10 text-gray-400'
                  }`}>
                    {provider.id === 'stripe' && <CreditCardIcon className="w-6 h-6" />}
                    {provider.id === 'kz' && <BanknotesIcon className="w-6 h-6" />}
                    {provider.id === 'crypto' && <CurrencyDollarIcon className="w-6 h-6" />}
                  </div>
                  <div>
                    <p className="font-black text-sm dark:text-white uppercase tracking-tight">{provider.label}</p>
                    <p className="text-xs text-gray-400 font-medium">{provider.description}</p>
                  </div>
                </div>
                {provider.comingSoon && (
                  <span className="text-[9px] font-black uppercase tracking-widest text-gray-400 bg-gray-100 dark:bg-white/10 px-3 py-1 rounded-full shrink-0">
                    {t('coming_soon') || 'Em breve'}
                  </span>
                )}
                {selectedMethod === provider.id && provider.enabled && (
                  <CheckCircleIcon className="w-6 h-6 text-brand shrink-0" />
                )}
              </button>
            ))}
          </div>

          {selectedMethod === 'stripe' && (
            <div className="pt-2">
              {loadingIntent && (
                <div className="flex items-center justify-center py-10">
                  <div className="w-8 h-8 border-4 border-brand border-t-transparent rounded-full animate-spin" />
                </div>
              )}

              {error && (
                <div className="flex items-start gap-3 bg-red-500/5 border border-red-500/10 rounded-2xl p-4">
                  <ExclamationCircleIcon className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-red-500 font-medium">{error}</p>
                </div>
              )}

              {clientSecret && amountEur !== null && (
                <StripeCheckoutForm
                  clientSecret={clientSecret}
                  intentId={intentId!}
                  amountEur={amountEur}
                  onSuccess={onSuccess}
                  onError={setError}
                />
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

interface StripeCheckoutFormProps {
  clientSecret: string;
  intentId: string;
  amountEur: number;
  onSuccess: () => void;
  onError: (msg: string) => void;
}

const StripeCheckoutForm: React.FC<StripeCheckoutFormProps> = ({ clientSecret, amountEur, onSuccess, onError }) => {
  const stripePromiseMemo = useMemo(() => getStripeJs(), []);
  const [stripeUnavailable, setStripeUnavailable] = useState(false);

  useEffect(() => {
    stripePromiseMemo.then((s) => {
      if (!s) setStripeUnavailable(true);
    });
  }, [stripePromiseMemo]);

  if (stripeUnavailable) {
    return (
      <div className="flex items-start gap-3 bg-amber-500/5 border border-amber-500/10 rounded-2xl p-4">
        <ExclamationCircleIcon className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <p className="text-xs text-amber-600 font-medium">
          O pagamento por cartão ainda não foi configurado pelo administrador (chave pública da Stripe em falta).
        </p>
      </div>
    );
  }

  return (
    <Elements stripe={stripePromiseMemo} options={{ clientSecret, locale: 'pt' }}>
      <InnerStripeForm amountEur={amountEur} onSuccess={onSuccess} onError={onError} />
    </Elements>
  );
};

const InnerStripeForm: React.FC<{ amountEur: number; onSuccess: () => void; onError: (msg: string) => void }> = ({
  amountEur,
  onSuccess,
  onError,
}) => {
  const { t } = useTranslation();
  const stripe = useStripe();
  const elements = useElements();
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setSubmitting(true);
    onError('');

    const { error: confirmError, paymentIntent } = await stripe.confirmPayment({
      elements,
      redirect: 'if_required',
    });

    if (confirmError) {
      onError(confirmError.message || 'Não foi possível processar o pagamento.');
      setSubmitting(false);
      return;
    }

    if (paymentIntent?.status === 'succeeded') {
      // O saldo só é creditado pelo webhook (fonte de verdade). Damos um
      // pequeno tempo de margem para o webhook chegar antes de notificar
      // sucesso na UI; em caso de demora, o usuário ainda pode atualizar.
      setTimeout(onSuccess, 1200);
    } else if (paymentIntent?.status === 'processing') {
      onSuccess(); // A confirmação assíncrona chegará via webhook; tratamos como sucesso "em processamento".
    } else {
      onError('O pagamento não foi concluído. Tente novamente.');
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <p className="text-[10px] text-center text-gray-400 font-medium">
        {t('charged_in_eur', { amount: amountEur.toFixed(2) }) || `Será cobrado o equivalente a € ${amountEur.toFixed(2)} no seu cartão.`}
      </p>
      <button
        type="submit"
        disabled={!stripe || submitting}
        className="w-full bg-brand text-white py-5 rounded-3xl font-black uppercase text-xs tracking-widest shadow-xl shadow-brand/20 active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-3"
      >
        {submitting ? (
          <>
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            {t('processing_transaction') || 'Processando...'}
          </>
        ) : (
          <>{t('pay_now') || 'Pagar agora'}</>
        )}
      </button>
    </form>
  );
};

export default CheckoutModal;
