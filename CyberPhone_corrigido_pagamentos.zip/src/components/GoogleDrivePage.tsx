import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { User, Page } from '../types';
import { 
  connectGoogleDrive, 
  getDriveAccessToken, 
  disconnectGoogleDrive, 
  listDriveContents, 
  createDriveFolder, 
  deleteDriveFile, 
  uploadFileToDrive, 
  DriveFile 
} from '../services/driveService';
import { 
  Cloud, 
  Folder, 
  FolderPlus, 
  File, 
  FileSpreadsheet, 
  FileImage, 
  FileVideo, 
  FileAudio, 
  FileText, 
  Trash2, 
  Plus, 
  Search, 
  ArrowLeft, 
  ExternalLink, 
  Loader2, 
  LogOut, 
  UploadCloud, 
  Grid, 
  List, 
  Info, 
  FolderOpen,
  X,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { useDialog } from '../services/DialogContext';

interface GoogleDrivePageProps {
  currentUser: User;
  onNavigate: (page: Page, params?: Record<string, string>) => void;
}

interface BreadcrumbItem {
  id: string;
  name: string;
}

export const GoogleDrivePage: React.FC<GoogleDrivePageProps> = ({ currentUser, onNavigate }) => {
  const { t } = useTranslation();
  const { showAlert } = useDialog();

  // Authentication & API state
  const [token, setToken] = useState<string | null>(getDriveAccessToken());
  const [loading, setLoading] = useState<boolean>(false);
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [debouncedSearch, setDebouncedSearch] = useState<string>('');
  
  // Navigation structure
  const [currentFolderId, setCurrentFolderId] = useState<string>('root');
  const [breadcrumbs, setBreadcrumbs] = useState<BreadcrumbItem[]>([
    { id: 'root', name: 'My Drive' }
  ]);

  // UI display mode
  const [isGridView, setIsGridView] = useState<boolean>(true);

  // Modal and action states
  const [isCreateFolderOpen, setIsCreateFolderOpen] = useState<boolean>(false);
  const [newFolderName, setNewFolderName] = useState<string>('');
  const [creatingFolder, setCreatingFolder] = useState<boolean>(false);

  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState<DriveFile | null>(null);
  const [deletingFile, setDeletingFile] = useState<boolean>(false);

  // Drag and Drop Upload States
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [uploadingFileName, setUploadingFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Debounce search input
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchQuery);
    }, 450);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Load files when token, current folder or query changes
  useEffect(() => {
    if (token) {
      fetchFiles();
    }
  }, [token, currentFolderId, debouncedSearch]);

  const fetchFiles = async () => {
    setLoading(true);
    try {
      const contents = await listDriveContents(token!, currentFolderId, debouncedSearch);
      setFiles(contents);
    } catch (error: any) {
      console.error('Error fetching drive files:', error);
      if (error.message && (error.message.includes('auth') || error.message.includes('expired') || error.message.includes('permission'))) {
        showAlert('Sua sessão do Google Drive expirou ou é inválida. Por favor, conecte novamente.', { type: 'error' });
        handleDisconnect();
      } else {
        showAlert(`Falha ao ler arquivos: ${error.message}`, { type: 'error' });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async () => {
    setLoading(true);
    try {
      const accessToken = await connectGoogleDrive();
      setToken(accessToken);
      showAlert('Conectado ao Google Drive com sucesso!', { type: 'success' });
    } catch (error: any) {
      showAlert(`Erro de autorização: ${error.message || 'Falha ao conectar'}`, { type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = () => {
    disconnectGoogleDrive();
    setToken(null);
    setFiles([]);
    setCurrentFolderId('root');
    setBreadcrumbs([{ id: 'root', name: 'My Drive' }]);
  };

  const navigateToFolder = (folderId: string, folderName: string) => {
    setSearchQuery(''); // Reset search when browsing folder
    setCurrentFolderId(folderId);
    
    // Update breadcrumbs
    const existingIndex = breadcrumbs.findIndex(item => item.id === folderId);
    if (existingIndex !== -1) {
      // If folder already in path, slice the path up to it
      setBreadcrumbs(breadcrumbs.slice(0, existingIndex + 1));
    } else {
      // Append new folder to breadcrumbs
      setBreadcrumbs([...breadcrumbs, { id: folderId, name: folderName }]);
    }
  };

  const navigateToBreadcrumb = (index: number) => {
    setSearchQuery('');
    const target = breadcrumbs[index];
    setCurrentFolderId(target.id);
    setBreadcrumbs(breadcrumbs.slice(0, index + 1));
  };

  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim() || !token) return;

    setCreatingFolder(true);
    try {
      await createDriveFolder(token, newFolderName.trim(), currentFolderId);
      showAlert(`Pasta "${newFolderName}" criada com sucesso!`, { type: 'success' });
      setNewFolderName('');
      setIsCreateFolderOpen(false);
      fetchFiles();
    } catch (error: any) {
      showAlert(`Erro ao criar pasta: ${error.message}`, { type: 'error' });
    } finally {
      setCreatingFolder(false);
    }
  };

  // Safe file deletion conforming to client instructions
  const handleDeleteConfirm = async () => {
    if (!deleteConfirmTarget || !token) return;

    setDeletingFile(true);
    try {
      await deleteDriveFile(token, deleteConfirmTarget.id);
      showAlert(`"${deleteConfirmTarget.name}" movido para a lixeira/excluído com sucesso!`, { type: 'success' });
      setDeleteConfirmTarget(null);
      fetchFiles();
    } catch (error: any) {
      showAlert(`Erro ao deletar: ${error.message}`, { type: 'error' });
    } finally {
      setDeletingFile(false);
    }
  };

  // Upload file handling
  const handleUploadFile = async (selectedFiles: FileList | null) => {
    if (!selectedFiles || selectedFiles.length === 0 || !token) return;
    const file = selectedFiles[0];
    
    setUploadingFileName(file.name);
    setUploadProgress(0);

    try {
      await uploadFileToDrive(token, file, currentFolderId, (prog) => {
        setUploadProgress(prog);
      });
      showAlert(`Upload de "${file.name}" concluído!`, { type: 'success' });
      fetchFiles();
    } catch (error: any) {
      showAlert(`Erro ao carregar arquivo: ${error.message}`, { type: 'error' });
    } finally {
      setUploadProgress(null);
      setUploadingFileName('');
    }
  };

  // Drag-and-drop utilities
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleUploadFile(e.dataTransfer.files);
    }
  };

  // Helper function to format sizes in human-readable terms
  const formatBytes = (bytesStr?: string) => {
    if (!bytesStr) return '--';
    const bytes = parseInt(bytesStr, 10);
    if (isNaN(bytes)) return '--';
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  // Helper helper to format DateTime beautifully
  const formatDateTime = (isoString?: string) => {
    if (!isoString) return '--';
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) + ' ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
    } catch {
      return isoString;
    }
  };

  // Retrieve proper icon corresponding to file type
  const getFileIcon = (mimeType: string) => {
    if (mimeType === 'application/vnd.google-apps.folder') {
      return <Folder className="w-8 h-8 text-amber-500 fill-amber-500/10" />;
    }
    if (mimeType.startsWith('image/')) {
      return <FileImage className="w-8 h-8 text-emerald-500" />;
    }
    if (mimeType.startsWith('video/')) {
      return <FileVideo className="w-8 h-8 text-rose-500" />;
    }
    if (mimeType.startsWith('audio/')) {
      return <FileAudio className="w-8 h-8 text-purple-500" />;
    }
    if (mimeType.includes('spreadsheet') || mimeType.includes('excel') || mimeType === 'application/vnd.google-apps.spreadsheet') {
      return <FileSpreadsheet className="w-8 h-8 text-green-500" />;
    }
    if (mimeType.includes('pdf') || mimeType.includes('document') || mimeType.includes('word') || mimeType === 'application/vnd.google-apps.document') {
      return <FileText className="w-8 h-8 text-blue-500" />;
    }
    return <File className="w-8 h-8 text-gray-500 dark:text-gray-400" />;
  };

  return (
    <div id="google-drive-explorer" className="w-full max-w-6xl mx-auto px-4 md:px-6 py-6 min-h-screen pb-32">
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 bg-white dark:bg-[#121620] p-6 rounded-[2rem] border border-gray-100 dark:border-white/5 shadow-2mod animate-fade-in">
        <div className="flex items-center gap-4">
          <button 
            type="button" 
            onClick={() => onNavigate('settings')}
            className="p-3 bg-gray-50 hover:bg-gray-100 dark:bg-white/5 dark:hover:bg-white/10 rounded-full transition-all text-gray-600 dark:text-gray-300"
            title="Voltar para Configurações"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <span className="text-[10px] uppercase font-black tracking-widest text-brand block mb-1">Integração Workspace</span>
            <div className="flex items-center gap-2">
              <Cloud className="w-7 h-7 text-blue-500 animate-pulse-slow" />
              <h1 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">Google Drive</h1>
            </div>
          </div>
        </div>

        {token && (
          <div className="flex items-center gap-3 bg-red-50 dark:bg-red-950/10 border border-red-500/10 px-4 py-2 rounded-2xl">
            <div className="flex flex-col text-right hidden sm:block">
              <span className="text-xs font-black text-gray-900 dark:text-white">Conexão Ativa</span>
              <span className="text-[10px] text-gray-500">Google Workspace</span>
            </div>
            <button 
              onClick={handleDisconnect}
              className="p-2.5 bg-red-500 hover:bg-red-600 dark:bg-red-500/20 dark:hover:bg-red-500/30 text-white dark:text-red-400 rounded-xl flex items-center gap-2 transition-all font-black text-[11px] uppercase tracking-wider"
              title="Desconectar do Google Drive"
            >
              <LogOut className="w-4 h-4" />
              <span>Desconectar</span>
            </button>
          </div>
        )}
      </div>

      {loading && !token && (
        <div className="flex flex-col items-center justify-center p-16 bg-white dark:bg-[#121620] rounded-[2.5rem] border border-gray-100 dark:border-white/5">
          <Loader2 className="w-12 h-12 text-brand animate-spin mb-4" />
          <p className="font-bold text-gray-600 dark:text-gray-300">Carregando permissões...</p>
        </div>
      )}

      {/* NOT CONNECTED STATE */}
      {!token && !loading && (
        <div className="flex flex-col items-center justify-center text-center p-8 md:p-16 bg-white dark:bg-[#121620] rounded-[2.5rem] border border-gray-100 dark:border-white/5 shadow-2mod max-w-2xl mx-auto animate-fade-in">
          <div className="w-20 h-20 bg-blue-50 dark:bg-blue-950/20 rounded-full flex items-center justify-center mb-6">
            <Cloud className="w-10 h-10 text-blue-500" />
          </div>
          <h2 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight mb-2">Acesse seus arquivos na Nuvem</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 max-w-md mb-8">
            Com a integração com o Google Drive, você pode navegar em pastas, criar novos diretórios, carregar mídias e excluir arquivos totalmente integrados ao CyBerPhone, de forma rápida e segura.
          </p>

          <button 
            onClick={handleConnect}
            className="flex items-center gap-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-200 font-extrabold px-6 py-3.5 rounded-2xl transition-all shadow-sm active:scale-95"
          >
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="w-5 h-5">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
            </svg>
            <span className="text-sm tracking-tight">Conectar com Google Drive</span>
          </button>
          
          <div className="flex items-center gap-2 mt-8 text-[11px] text-gray-400 dark:text-gray-500 bg-gray-50 dark:bg-white/5 px-4 py-2 rounded-xl">
            <Info className="w-3.5 h-3.5" />
            <span>Seus arquivos reais estão protegidos de acordo com as políticas de privacidade do Google.</span>
          </div>
        </div>
      )}

      {/* CONNECTED EXPLORER STATE */}
      {token && (
        <div className="space-y-6 animate-fade-in">
          
          {/* CONTROL BAR AND ACTIONS */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* SEARCH AND NAVIGATION */}
            <div className="lg:col-span-2 flex flex-col gap-4 bg-white dark:bg-[#121620] p-6 rounded-[2rem] border border-gray-100 dark:border-white/5 shadow-2mod">
              <div>
                <span className="text-[10px] font-black uppercase text-gray-400 tracking-wider">Localização Atual</span>
                {/* BREADCRUMB BROWSER */}
                <div className="flex flex-wrap items-center gap-1.5 mt-2 bg-gray-50 dark:bg-white/5 p-3 rounded-2xl overflow-hidden text-sm">
                  {breadcrumbs.map((crumb, idx) => (
                    <React.Fragment key={crumb.id}>
                      {idx > 0 && <span className="text-gray-300 dark:text-gray-600 font-bold">/</span>}
                      <button 
                        onClick={() => navigateToBreadcrumb(idx)}
                        className={`font-black hover:text-brand transition-colors text-xs uppercase tracking-wider ${
                          idx === breadcrumbs.length - 1 
                            ? 'text-brand underline decoration-brand/30 underline-offset-4' 
                            : 'text-gray-500 dark:text-gray-400'
                        }`}
                      >
                        {crumb.name}
                      </button>
                    </React.Fragment>
                  ))}
                </div>
              </div>

              {/* SEARCH INPUT */}
              <div className="relative">
                <Search className="absolute left-4 top-3.5 text-gray-400 w-5 h-5 pointer-events-none" />
                <input 
                  type="text"
                  placeholder="Pesquisar nos arquivos..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-white/5 border border-transparent focus:border-brand/30 focus:bg-white dark:focus:bg-transparent rounded-2xl pl-12 pr-4 py-3 text-sm text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none transition-all"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute right-4 top-3.5 text-gray-400 hover:text-gray-600 dark:hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* QUICK ACTIONS BUTTONS */}
            <div className="flex flex-col sm:flex-row lg:flex-col justify-stretch gap-4 bg-white dark:bg-[#121620] p-6 rounded-[2rem] border border-gray-100 dark:border-white/5 shadow-2mod">
              <button 
                onClick={() => setIsCreateFolderOpen(true)}
                className="flex-1 flex items-center justify-center gap-3 bg-amber-500 hover:bg-amber-600 text-white font-black text-xs uppercase tracking-wider py-4 px-6 rounded-2xl transition-all shadow-md active:scale-95"
              >
                <FolderPlus className="w-5 h-5" />
                <span>Nova Pasta</span>
              </button>
              
              <div className="flex items-center justify-between gap-2 border-t lg:border-t lg:pt-4 sm:border-t-0 sm:pt-0 border-gray-100 dark:border-white/5">
                <span className="text-xs font-black uppercase text-gray-400 tracking-wider">Visualização:</span>
                <div className="flex bg-gray-50 dark:bg-white/5 p-1 rounded-xl">
                  <button 
                    onClick={() => setIsGridView(true)}
                    className={`p-2 rounded-lg transition-all ${isGridView ? 'bg-brand text-white' : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'}`}
                    title="Visualizar em Grade"
                  >
                    <Grid className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setIsGridView(false)}
                    className={`p-2 rounded-lg transition-all ${!isGridView ? 'bg-brand text-white' : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'}`}
                    title="Visualizar em Lista"
                  >
                    <List className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

          </div>

          {/* DYNAMIC FILE UPLOAD CONTAINER (DRAG-AND-DROP + MANUAL SELECTION) */}
          <div 
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`w-full border-2 border-dashed rounded-[2rem] p-6 text-center transition-all ${
              dragActive 
                ? 'border-brand bg-brand/5 scale-[1.01]' 
                : 'border-gray-200 dark:border-white/10 bg-white dark:bg-[#121620] hover:border-brand/40'
            }`}
          >
            <input 
              type="file"
              ref={fileInputRef}
              onChange={(e) => handleUploadFile(e.target.files)}
              className="hidden"
            />
            {uploadProgress !== null ? (
              <div className="flex flex-col items-center justify-center py-4">
                <Loader2 className="w-10 h-10 text-brand animate-spin mb-3" />
                <span className="text-sm font-black text-gray-900 dark:text-white uppercase tracking-wider mb-2">
                  Carregando {uploadingFileName} ({uploadProgress}%)
                </span>
                <div className="w-full max-w-md bg-gray-100 dark:bg-white/5 rounded-full h-2.5 overflow-hidden">
                  <div 
                    className="bg-brand h-full transition-all duration-300 rounded-full" 
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
              </div>
            ) : (
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="flex flex-col items-center justify-center cursor-pointer py-4"
              >
                <div className="w-12 h-12 bg-brand/10 text-brand rounded-full flex items-center justify-center mb-3">
                  <UploadCloud className="w-6 h-6 animate-pulse-slow" />
                </div>
                <p className="font-bold text-sm text-gray-700 dark:text-gray-300">
                  Arraste e solte arquivos aqui ou <span className="text-brand hover:underline font-black">clique para selecionar</span>
                </p>
                <p className="text-xs text-gray-400 mt-1">Carregue diretamente para a localização atual no seu Drive.</p>
              </div>
            )}
          </div>

          {/* FILE CONTENTS AREA */}
          <div className="bg-white dark:bg-[#121620] p-6 rounded-[2.5rem] border border-gray-100 dark:border-white/5 shadow-2mod">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-20">
                <Loader2 className="w-10 h-10 text-brand animate-spin mb-3" />
                <p className="text-sm text-gray-500">Sincronizando com o Google Drive...</p>
              </div>
            ) : files.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <div className="w-16 h-16 bg-gray-50 dark:bg-white/5 rounded-full flex items-center justify-center mb-4">
                  <FolderOpen className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="font-exbold text-gray-800 dark:text-white text-base">Nenhum arquivo encontrado</h3>
                <p className="text-xs text-gray-400 mt-1 max-w-sm">Esta pasta está vazia ou nenhum item corresponde à sua pesquisa.</p>
              </div>
            ) : (
              <div>
                {/* GRID VIEW */}
                {isGridView ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {files.map((file) => {
                      const isFolder = file.mimeType === 'application/vnd.google-apps.folder';
                      return (
                        <div 
                          key={file.id}
                          className="group relative bg-gray-50 hover:bg-gray-100 dark:bg-white/5 dark:hover:bg-white/10 border border-transparent dark:border-white/5 rounded-2xl p-4 flex flex-col justify-between transition-all hover:scale-[1.01]"
                        >
                          <div className="absolute right-2 top-2 hidden group-hover:flex items-center gap-1.5 bg-white/90 dark:bg-black/80 backdrop-blur-md p-1.5 rounded-xl border border-gray-100 dark:border-white/10 shadow-md">
                            {file.webViewLink && (
                              <a 
                                href={file.webViewLink} 
                                target="_blank" 
                                rel="noreferrer"
                                className="p-1 hover:text-brand text-gray-500 rounded-md transition-colors"
                                title="Visualizar no Drive"
                              >
                                <ExternalLink className="w-4 h-4" />
                              </a>
                            )}
                            <button 
                              onClick={() => setDeleteConfirmTarget(file)}
                              className="p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/15 rounded-md transition-all"
                              title="Excluir arquivo"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          <div 
                            className={`flex flex-col items-center text-center py-4 cursor-pointer ${isFolder ? 'hover:brightness-95' : ''}`}
                            onClick={() => isFolder ? navigateToFolder(file.id, file.name) : file.webViewLink && window.open(file.webViewLink, '_blank')}
                          >
                            <div className="mb-3">
                              {getFileIcon(file.mimeType)}
                            </div>
                            <h4 className="font-extrabold text-sm text-gray-900 dark:text-gray-100 tracking-tight line-clamp-2 px-1 text-center w-full" title={file.name}>
                              {file.name}
                            </h4>
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-gray-400 border-t border-gray-100 dark:border-white/5 pt-2.5 mt-2">
                            <span>{isFolder ? 'Pasta' : formatBytes(file.size)}</span>
                            <span>{formatDateTime(file.createdTime).split(' ')[0]}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  /* LIST VIEW */
                  <div className="w-full overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-gray-100 dark:border-white/5 text-[10px] font-black uppercase tracking-widest text-gray-400">
                          <th className="pb-3 pl-4">Nome</th>
                          <th className="pb-3">Data de Criação</th>
                          <th className="pb-3">Tamanho</th>
                          <th className="pb-3 text-right pr-4">Ações</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 dark:divide-white/5">
                        {files.map((file) => {
                          const isFolder = file.mimeType === 'application/vnd.google-apps.folder';
                          return (
                            <tr 
                              key={file.id}
                              className="group hover:bg-gray-50/50 dark:hover:bg-white/5 transition-all"
                            >
                              <td className="py-3 pl-4">
                                <div 
                                  className="flex items-center gap-3 cursor-pointer"
                                  onClick={() => isFolder ? navigateToFolder(file.id, file.name) : file.webViewLink && window.open(file.webViewLink, '_blank')}
                                >
                                  {getFileIcon(file.mimeType)}
                                  <span className="font-bold text-sm text-gray-900 dark:text-white group-hover:text-brand transition-colors max-w-xs md:max-w-md truncate">
                                    {file.name}
                                  </span>
                                </div>
                              </td>
                              <td className="py-3 text-xs text-gray-500">{formatDateTime(file.createdTime)}</td>
                              <td className="py-3 text-xs text-gray-500">{isFolder ? 'Pasta' : formatBytes(file.size)}</td>
                              <td className="py-3 text-right pr-4">
                                <div className="flex items-center justify-end gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                  {file.webViewLink && (
                                    <a 
                                      href={file.webViewLink} 
                                      target="_blank" 
                                      rel="noreferrer"
                                      className="p-1.5 text-gray-400 hover:text-brand bg-gray-100 dark:bg-white/5 rounded-lg"
                                      title="Abrir no Drive"
                                    >
                                      <ExternalLink className="w-4 h-4" />
                                    </a>
                                  )}
                                  <button 
                                    onClick={() => setDeleteConfirmTarget(file)}
                                    className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/20 rounded-lg"
                                    title="Deletar permanentemente"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>

        </div>
      )}

      {/* MODAL: CREATE NEW FOLDER */}
      {isCreateFolderOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white dark:bg-[#121620] w-full max-w-md rounded-[2.5rem] border border-gray-100 dark:border-white/5 p-6 shadow-2xl relative animate-scale-up">
            <button 
              onClick={() => setIsCreateFolderOpen(false)}
              className="absolute right-5 top-5 p-2 bg-gray-50 dark:bg-white/5 hover:bg-gray-100 dark:hover:bg-white/10 rounded-full text-gray-400 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
            
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-amber-500/10 text-amber-500 rounded-full flex items-center justify-center mx-auto mb-3">
                <FolderPlus className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-black text-gray-950 dark:text-white tracking-tight">Criar Nova Pasta</h3>
              <p className="text-xs text-gray-400 mt-1">Dê um nome para a pasta que será criada no Google Drive.</p>
            </div>

            <form onSubmit={handleCreateFolder} className="space-y-4">
              <div>
                <input 
                  type="text"
                  placeholder="Nome da pasta"
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-white/5 border border-transparent focus:border-amber-500/30 rounded-2xl p-4 text-sm focus:outline-none transition-all dark:text-white font-bold"
                  autoFocus
                  required
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsCreateFolderOpen(false)}
                  className="flex-1 bg-gray-50 hover:bg-gray-100 dark:bg-white/5 dark:hover:bg-white/10 text-gray-600 dark:text-gray-300 py-3.5 px-6 rounded-2xl font-black text-xs uppercase tracking-wider text-center"
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  disabled={creatingFolder || !newFolderName.trim()}
                  className="flex-1 bg-amber-500 hover:bg-amber-600 text-white font-black text-xs uppercase tracking-wider py-3.5 px-6 rounded-2xl flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                >
                  {creatingFolder ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Criar Pasta'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: DESTRUCTIVE ACTION VERIFICATION (MANDATORY VERIFICATION AS PER MANUAL DETAILED PROCEDURES) */}
      {deleteConfirmTarget && (
        <div id="drive-delete-confirm-dialog" className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white dark:bg-[#121620] w-full max-w-md rounded-[2.5rem] border border-gray-100 dark:border-white/5 p-6 shadow-2xl relative animate-scale-up">
            <button 
              onClick={() => setDeleteConfirmTarget(null)}
              className="absolute right-5 top-5 p-2 bg-gray-50 dark:bg-white/5 hover:bg-gray-100 dark:hover:bg-white/10 rounded-full text-gray-400 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
            
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-red-100 dark:bg-red-950/20 text-red-500 rounded-full flex items-center justify-center mx-auto mb-3 animate-bounce">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-black text-gray-950 dark:text-white tracking-tight">Confirmar Exclusão</h3>
              <p className="text-xs text-gray-400 mt-1.5 max-w-xs mx-auto">
                Você tem certeza que deseja deletar permanentemente este item? Esta ação mutará dados reais no seu Google Drive.
              </p>
            </div>

            <div className="bg-gray-50 dark:bg-white/5 p-4 rounded-2xl mb-6 text-center border border-gray-100 dark:border-white/5">
              <span className="font-extrabold text-sm text-gray-900 dark:text-white break-all">
                {deleteConfirmTarget.name}
              </span>
              <div className="text-[10px] text-gray-400 mt-1">
                {deleteConfirmTarget.mimeType === 'application/vnd.google-apps.folder' ? 'Categoria: Pasta' : `Tamanho: ${formatBytes(deleteConfirmTarget.size)}`}
              </div>
            </div>

            <div className="flex gap-3">
              <button 
                type="button" 
                onClick={() => setDeleteConfirmTarget(null)}
                className="flex-1 bg-gray-50 hover:bg-gray-100 dark:bg-white/5 dark:hover:bg-white/10 text-gray-600 dark:text-gray-300 py-3.5 px-6 rounded-2xl font-black text-xs uppercase tracking-wider text-center"
              >
                Manter Arquivo
              </button>
              <button 
                type="button" 
                onClick={handleDeleteConfirm}
                disabled={deletingFile}
                className="flex-1 bg-red-500 hover:bg-red-600 text-white font-black text-xs uppercase tracking-wider py-3.5 px-6 rounded-2xl flex items-center justify-center gap-2 transition-all"
              >
                {deletingFile ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Excluir Item'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
