import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged } from 'firebase/auth';
import { auth } from './firebaseClient';

// In-memory cache for the Google OAuth 2.0 Access Token
let cachedAccessToken: string | null = null;
let isSigningIn = false;

// Listen to auth changes to invalidate cache if user logs out of the main app
if (auth) {
  onAuthStateChanged(auth, (user) => {
    if (!user) {
      cachedAccessToken = null;
    }
  });
}

/**
 * Initiates a Google Sign-In popup with Google Drive scope
 */
export const connectGoogleDrive = async (): Promise<string> => {
  if (!auth) {
    throw new Error('Firebase Authentication is not initialized.');
  }

  isSigningIn = true;
  try {
    const provider = new GoogleAuthProvider();
    // Scope for full Google Drive management
    provider.addScope('https://www.googleapis.com/auth/drive');
    provider.setCustomParameters({ prompt: 'consent select_account' });

    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    
    if (!credential || !credential.accessToken) {
      throw new Error('Failed to retrieve Google Access Token.');
    }

    cachedAccessToken = credential.accessToken;
    return cachedAccessToken;
  } catch (error: any) {
    console.error('[DRIVE_SERVICE] Error during connection:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Gets the current cached access token
 */
export const getDriveAccessToken = (): string | null => {
  return cachedAccessToken;
};

/**
 * Clears the in-memory access token cache
 */
export const disconnectGoogleDrive = () => {
  cachedAccessToken = null;
};

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  createdTime?: string;
  iconLink?: string;
  webViewLink?: string;
}

/**
 * Lists files and folders from a specific parent directory or root
 */
export const listDriveContents = async (
  token: string, 
  parentId: string = 'root', 
  searchQuery?: string
): Promise<DriveFile[]> => {
  try {
    let q = `'${parentId}' in parents and trashed = false`;
    if (searchQuery && searchQuery.trim() !== '') {
      // Escape single quotes in search query
      const escapedQuery = searchQuery.replace(/'/g, "\\'");
      q = `name contains '${escapedQuery}' and trashed = false`;
      if (parentId !== 'root') {
        q += ` and '${parentId}' in parents`;
      }
    }

    const fields = 'files(id, name, mimeType, size, createdTime, iconLink, webViewLink)';
    const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=${encodeURIComponent(fields)}&orderBy=folder,name`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error?.message || 'Failed to list Google Drive files.');
    }

    const data = await response.json();
    return data.files || [];
  } catch (error: any) {
    console.error('[DRIVE_SERVICE] listDriveContents failed:', error);
    throw error;
  }
};

/**
 * Creates a new folder inside Google Drive
 */
export const createDriveFolder = async (
  token: string,
  folderName: string,
  parentId: string = 'root'
): Promise<DriveFile> => {
  try {
    const url = 'https://www.googleapis.com/drive/v3/files';
    const metadata = {
      name: folderName,
      mimeType: 'application/vnd.google-apps.folder',
      parents: parentId !== 'root' ? [parentId] : undefined,
    };

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(metadata),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error?.message || 'Failed to create folder.');
    }

    return await response.json();
  } catch (error: any) {
    console.error('[DRIVE_SERVICE] createDriveFolder failed:', error);
    throw error;
  }
};

/**
 * Deletes a file or folder in Google Drive (destructive)
 */
export const deleteDriveFile = async (token: string, fileId: string): Promise<void> => {
  try {
    const url = `https://www.googleapis.com/drive/v3/files/${fileId}`;
    const response = await fetch(url, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error?.message || 'Failed to delete file.');
    }
  } catch (error: any) {
    console.error('[DRIVE_SERVICE] deleteDriveFile failed:', error);
    throw error;
  }
};

/**
 * Uploads a file to Google Drive (supports folder nesting via parentId)
 */
export const uploadFileToDrive = async (
  token: string,
  file: File,
  parentId: string = 'root',
  onProgress?: (progress: number) => void
): Promise<DriveFile> => {
  try {
    const metadata = {
      name: file.name,
      mimeType: file.type || 'application/octet-stream',
      parents: parentId !== 'root' ? [parentId] : undefined,
    };

    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', file);

    const url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';

    // Using XMLHttpRequest to support upload progress monitoring
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);
      xhr.setRequestHeader('Authorization', `Bearer ${token}`);

      if (xhr.upload && onProgress) {
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            const pct = Math.round((e.loaded / e.total) * 100);
            onProgress(pct);
          }
        };
      }

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const data = JSON.parse(xhr.responseText);
            resolve(data);
          } catch (err) {
            reject(new Error('Invalid response JSON.'));
          }
        } else {
          try {
            const errorData = JSON.parse(xhr.responseText);
            reject(new Error(errorData.error?.message || 'Failed to upload file.'));
          } catch {
            reject(new Error('Status code ' + xhr.status + ' during file upload.'));
          }
        }
      };

      xhr.onerror = () => {
        reject(new Error('Network error during Google Drive upload.'));
      };

      xhr.send(form);
    });
  } catch (error: any) {
    console.error('[DRIVE_SERVICE] uploadFileToDrive failed:', error);
    throw error;
  }
};
