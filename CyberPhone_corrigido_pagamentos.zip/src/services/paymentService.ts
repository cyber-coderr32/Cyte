import type { CartItem, PaymentMethod, ShippingAddress } from '../types';

/**
 * Camada de orquestração de pagamentos do CyberPhone.
 *
 * Esta camada existe para que o checkout e a carteira nunca precisem saber
 * os detalhes de cada provedor. Hoje só o adaptador Stripe está realmente
 * ativo; KZ (Multicaixa Express / Unitel Money) e Cripto (USDT) já têm a
 * interface pronta — quando as respetivas APIs estiverem disponíveis,
 * basta implementar a função correspondente e marcar `enabled: true` em
 * PAYMENT_PROVIDERS, sem tocar em nenhum componente de UI.
 */

export interface CreatePaymentIntentParams {
  userId: string;
  amountKz: number;
  purpose: 'WALLET_DEPOSIT' | 'CART_CHECKOUT';
  cartItems?: CartItem[];
  shippingAddress?: ShippingAddress;
  carrier?: { id: string; name: string };
  affiliateId?: string | null;
}

export interface CreatePaymentIntentResult {
  clientSecret: string;
  intentId: string;
  amountEur: number;
  eurToKzRate: number;
}

/** Catálogo de métodos de pagamento exibidos no checkout. */
export const PAYMENT_PROVIDERS: { id: PaymentMethod; label: string; description: string; enabled: boolean; comingSoon?: boolean }[] = [
  {
    id: 'stripe',
    label: 'Cartão (Stripe)',
    description: 'Visa, Mastercard e outros cartões internacionais',
    enabled: true,
  },
  {
    id: 'kz',
    label: 'Multicaixa / Unitel Money',
    description: 'Pagamento local em Kwanzas',
    enabled: false,
    comingSoon: true,
  },
  {
    id: 'crypto',
    label: 'Criptomoeda (USDT)',
    description: 'Pagamento via USDT (Tether)',
    enabled: false,
    comingSoon: true,
  },
];

/**
 * Solicita ao backend a criação de um PaymentIntent Stripe e devolve o
 * clientSecret necessário para confirmar o pagamento com Stripe Elements
 * no frontend (ver CheckoutModal.tsx).
 */
export async function createStripePaymentIntent(params: CreatePaymentIntentParams): Promise<CreatePaymentIntentResult> {
  const response = await fetch('/api/stripe/create-payment-intent', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error || 'Falha ao iniciar o pagamento. Tente novamente.');
  }
  return data;
}

/** Consulta o estado de uma intenção de pagamento (complementar à confirmação via Stripe.js). */
export async function getPaymentIntentStatus(intentId: string): Promise<{ status: string; purpose: string; amountKz: number }> {
  const response = await fetch(`/api/stripe/payment-intent/${intentId}/status`);
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error || 'Falha ao consultar o estado do pagamento.');
  }
  return data;
}

// ---------------------------------------------------------------------------
// Adaptadores futuros — KZ (Multicaixa Express / Unitel Money) e Cripto (USDT)
// ---------------------------------------------------------------------------
// Mantidos como stubs explícitos para que, quando a API local ou a de cripto
// estiverem prontas, baste preencher o corpo da função (chamando a rota de
// backend correspondente, que também precisará ser criada em server/).
// O contrato de retorno é mantido o mais parecido possível com o do Stripe
// para minimizar mudanças no CheckoutModal.

export async function createKzPaymentIntent(_params: CreatePaymentIntentParams): Promise<never> {
  throw new Error('O pagamento via Multicaixa/Unitel Money ainda não está disponível nesta versão.');
}

export async function createCryptoPaymentIntent(_params: CreatePaymentIntentParams): Promise<never> {
  throw new Error('O pagamento via criptomoeda (USDT) ainda não está disponível nesta versão.');
}

// ---------------------------------------------------------------------------
// Stripe Connect (Custom) — onboarding de vendedores e cartão virtual
// ---------------------------------------------------------------------------

export interface ConnectOnboardResult {
  url: string;
  stripeAccountId: string;
}

export async function startStripeConnectOnboarding(userId: string, email: string, country?: string): Promise<ConnectOnboardResult> {
  const response = await fetch('/api/stripe/connect/onboard', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, email, country }),
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error || 'Falha ao iniciar a configuração da conta bancária.');
  }
  return data;
}

export interface ConnectStatusResult {
  status: 'NOT_STARTED' | 'INFO_REQUIRED' | 'PENDING_REVIEW' | 'ACTIVE' | 'RESTRICTED' | 'REJECTED';
  payoutsEnabled?: boolean;
  chargesEnabled?: boolean;
  detailsSubmitted?: boolean;
  requirementsCurrentlyDue?: string[];
  requirementsPastDue?: string[];
  bankAccountLast4?: string | null;
  bankAccountCountry?: string | null;
  stripeAccountId?: string;
}

export async function getStripeConnectStatus(userId: string): Promise<ConnectStatusResult> {
  const response = await fetch(`/api/stripe/connect/status/${userId}`);
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error || 'Falha ao consultar o estado da conta bancária.');
  }
  return data;
}

export interface VirtualCardResult {
  id: string;
  last4: string;
  expMonth: number;
  expYear: number;
  brand: string;
  status: string;
}

export async function requestVirtualCard(params: {
  userId: string;
  name: string;
  email?: string;
  billingAddress: { line1: string; city: string; postal_code: string; country: string; state?: string };
}): Promise<VirtualCardResult> {
  const response = await fetch('/api/stripe/connect/issuing/card', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error || 'Falha ao solicitar o cartão virtual.');
  }
  return data;
}

export async function listVirtualCards(userId: string): Promise<VirtualCardResult[]> {
  const response = await fetch(`/api/stripe/connect/issuing/cards/${userId}`);
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error || 'Falha ao listar os cartões virtuais.');
  }
  return data;
}
