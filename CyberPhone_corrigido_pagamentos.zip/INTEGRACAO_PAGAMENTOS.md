# CyberPhone — Correções e Integração de Pagamentos (Stripe)

Este documento resume tudo o que foi alterado no projeto.

---

## 1. Erros de navegação corrigidos

- **`'post-detail'` não tinha rota.** Ao clicar num post promovido em destaque no Feed, a app tentava navegar para a página `post-detail`, que não existia no roteador do `App.tsx` — o utilizador caía de volta no Feed normal, sem ver o post. Foi adicionado o `case 'post-detail'` que busca o post (`getPostById`) e mostra o `PostDetailModal` sobre o Feed, com estados de carregamento e erro tratados.
- Foram revisadas **todas** as outras chamadas de navegação (`onNavigate('...')`) em todos os componentes — nenhuma outra inconsistência foi encontrada.
- `IndicateModal` e `GroupDiscoveryCard` continuam como **stubs vazios** (já existiam assim antes desta tarefa) — não bloqueiam a app, mas a funcionalidade de "denunciar publicação" e "descoberta de grupos no feed" não fazem nada visualmente. Não foram implementados porque não fizeram parte do pedido original; avise se quiser que sejam construídos.

---

## 2. Falha de segurança crítica corrigida

**O problema:** qualquer usuário autenticado podia, usando as ferramentas de desenvolvedor do navegador, escrever diretamente no Firestore e alterar o próprio saldo (`balance`), saldo pendente (`pendingBalance`), ganhos totais (`totalEarnings`) ou até desbloquear a própria conta (`isFrozen`) — sem passar por nenhuma validação do servidor. Isso não era só uma simulação de UI: era uma vulnerabilidade real de escrita direta no banco de dados.

**A correção:** foi adicionado o **Firebase Admin SDK** no backend (`server/firebaseAdmin.ts`), e **todas** as 20+ funções que alteravam saldo foram migradas do cliente para rotas de backend que usam esse SDK (que ignora as regras do Firestore e por isso só pode ser acionado pelo servidor, nunca pelo navegador). As `firestore.rules` foram atualizadas para **remover `balance`, `pendingBalance`, `totalEarnings`, `totalWithdrawn`, `isFrozen` e `fundsReleased`** da lista de campos que o cliente pode escrever, mesmo sendo o próprio dono do perfil.

Funcionalidades migradas: depósito/levantamento, compra com saldo, boost de post, promoção de produto/carrossel, investimento em anúncios, taxa de verificação, taxa de criação de grupo, taxa de verificação de loja, doações, cancelamento de pedido, liberação de fundos (escrow), reembolso, decisão de devolução, bloqueio de conta por fraude (Sentinela AI), e ajuste manual de saldo pelo admin.

**Risco residual conhecido (não corrigido, por ser de escopo menor):** ao criar a conta por e-mail/senha pela primeira vez, o cliente ainda define o saldo de boas-vindas (1000 KZ) localmente antes de gravar — a regra de `create` no Firestore permite isso. Como só pode ocorrer uma vez por conta (não é repetível) e o valor é fixo no código do cliente, o risco prático é baixo, mas se quiser fechar 100%, esse fluxo também pode ser movido para o backend numa próxima iteração.

---

## 3. Stripe — Checkout multi-método (cartão / KZ / Cripto)

Foi criada uma camada de checkout que aceita 3 métodos, com **Stripe totalmente funcional** e os outros dois prontos para serem ligados quando você tiver as APIs:

- **Stripe (cartão internacional)** — funcional. Cobra em **EUR** (a Stripe não processa pagamentos em Kwanza/Angola diretamente), com taxa de conversão inicial de **1 EUR = 1200 KZ**, ajustável no Firestore em `settings/global` campo `eurToKzRate`.
- **Multicaixa Express / Unitel Money (KZ)** — aparece na interface como "Em breve". Quando tiver a API, o código novo já tem o lugar certo para encaixar (`src/services/paymentService.ts`, função `createKzPaymentIntent`).
- **USDT (Cripto)** — mesma lógica, função `createCryptoPaymentIntent` já existe como stub.

O fluxo de pagamento por cartão (Stripe) usa **PaymentIntents + Stripe Elements**, e o saldo só é creditado quando o **webhook** confirma o pagamento (nunca confiando só na resposta do navegador) — esse é o padrão de segurança recomendado pela própria Stripe.

### Depósito manual (Multicaixa/Unitel) deixou de ser "simulado"
Antes, clicar em "confirmar pagamento simulado" creditava saldo na hora, sem nenhuma verificação real. Agora isso cria um **pedido pendente** (`wallet_requests`) que só é aprovado manualmente por um administrador (rotas `/api/wallet/requests/:id/approve` e `/reject`), e só nesse momento o saldo é de fato alterado.

---

## 4. Stripe Connect (Custom) + Stripe Issuing (cartão virtual)

Foi implementado o fluxo completo que você pediu:

1. Cada vendedor/criador pode iniciar o **onboarding bancário** (Configurações → Pagamentos & Conta Bancária), que abre o fluxo hospedado pela própria Stripe (KYC, dados pessoais, IBAN).
2. Quando a conta estiver **ativa**, o usuário pode solicitar um **cartão virtual** (Stripe Issuing) vinculado à própria conta Connect, para gastar o saldo das vendas.

Aviso importante repetido aqui por registro: você escolheu o modelo **Custom** do Stripe Connect, que é o mais complexo e que a Stripe tipicamente só libera para contas já estabelecidas com volume e compliance própria. Há um risco real da Stripe **recusar ou suspender** a ativação dessa funcionalidade para uma conta nova. Se isso acontecer, a solução mais rápida é pedir para trocar `type: "custom"` para `type: "express"` em `server/stripeConnectRoutes.ts` — a estrutura de banco de dados e a UI não precisam mudar, só esse parâmetro e o fluxo de onboarding (que passa a ser ainda mais simples).

---

## 5. O que você precisa configurar antes de usar

Copie `.env.example` para `.env` e preencha:

```
STRIPE_SECRET_KEY=sk_test_...       # Nunca compartilhe esta chave
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...      # Gerado ao criar o endpoint de webhook no Dashboard
APP_PUBLIC_URL=https://seuapp.com
FIREBASE_SERVICE_ACCOUNT_JSON={"type":"service_account",...}   # JSON inteiro numa linha
```

**Passos no Dashboard da Stripe:**
1. Ativar **Connect** (modo Custom) em Settings → Connect.
2. Ativar **Issuing** em Settings → Issuing (pode exigir aprovação adicional da Stripe).
3. Criar um endpoint de Webhook apontando para `https://seuapp.com/api/stripe/webhook`, escutando os eventos `payment_intent.succeeded` e `payment_intent.payment_failed`. Copiar o "Signing secret" para `STRIPE_WEBHOOK_SECRET`.

**Firebase:**
1. Console do Firebase → Configurações do Projeto → Contas de Serviço → Gerar nova chave privada.
2. Copiar o conteúdo inteiro do JSON gerado para a variável `FIREBASE_SERVICE_ACCOUNT_JSON`.
3. Publicar as novas `firestore.rules` (Firebase Console → Firestore → Regras, ou via CLI `firebase deploy --only firestore:rules`).

**Depois disso:**
```bash
npm install
npm run dev
```

---

## 6. Resumo de ficheiros novos/alterados

**Backend (novo):**
- `server/firebaseAdmin.ts` — inicialização do Firebase Admin SDK
- `server/stripeClient.ts` — inicialização do cliente Stripe + conversão KZ↔EUR
- `server/stripeRoutes.ts` — checkout/depósito Stripe + webhook
- `server/stripeConnectRoutes.ts` — onboarding Connect + Issuing
- `server/checkoutFulfillment.ts` — finalização de compras pagas via Stripe
- `server/walletRoutes.ts` — checkout com saldo, pedidos manuais de depósito/levantamento
- `server/walletFeeRoutes.ts` — taxas de plataforma (boost, anúncios, verificação, etc.)
- `server/escrowRoutes.ts` — cancelamento, liberação de fundos, devoluções

**Frontend (novo):**
- `src/services/paymentService.ts`
- `src/components/CheckoutModal.tsx`
- `src/components/StripeConnectPanel.tsx`

**Alterados:** `server.ts`, `src/types.ts`, `src/i18n.ts`, `src/App.tsx`, `src/services/storageService.ts`, `src/components/CartPage.tsx`, `src/components/WalletModal.tsx`, `src/components/SettingsPage.tsx`, `package.json`, `.env.example`, `firestore.rules`.
